/****************************************************************************
** Meta object code from reading C++ file 'searchwin.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.14.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../DepotManagement/searchwin.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'searchwin.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.14.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_SearchWin_t {
    QByteArrayData data[29];
    char stringdata0[464];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_SearchWin_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_SearchWin_t qt_meta_stringdata_SearchWin = {
    {
QT_MOC_LITERAL(0, 0, 9), // "SearchWin"
QT_MOC_LITERAL(1, 10, 11), // "ObjectLabel"
QT_MOC_LITERAL(2, 22, 0), // ""
QT_MOC_LITERAL(3, 23, 5), // "label"
QT_MOC_LITERAL(4, 29, 10), // "ObjectName"
QT_MOC_LITERAL(5, 40, 4), // "name"
QT_MOC_LITERAL(6, 45, 10), // "ObjectType"
QT_MOC_LITERAL(7, 56, 4), // "Type"
QT_MOC_LITERAL(8, 61, 10), // "ObjectDate"
QT_MOC_LITERAL(9, 72, 4), // "from"
QT_MOC_LITERAL(10, 77, 2), // "to"
QT_MOC_LITERAL(11, 80, 13), // "ObjectDueDate"
QT_MOC_LITERAL(12, 94, 4), // "date"
QT_MOC_LITERAL(13, 99, 12), // "StorageLabel"
QT_MOC_LITERAL(14, 112, 10), // "FloorLabel"
QT_MOC_LITERAL(15, 123, 3), // "sto"
QT_MOC_LITERAL(16, 127, 3), // "flo"
QT_MOC_LITERAL(17, 131, 11), // "PicturePath"
QT_MOC_LITERAL(18, 143, 4), // "path"
QT_MOC_LITERAL(19, 148, 12), // "PictureLabel"
QT_MOC_LITERAL(20, 161, 34), // "on_Object_Label_pushButton_cl..."
QT_MOC_LITERAL(21, 196, 33), // "on_Object_Name_pushButton_cli..."
QT_MOC_LITERAL(22, 230, 33), // "on_Object_Date_pushButton_cli..."
QT_MOC_LITERAL(23, 264, 36), // "on_Object_DueDate_pushButton_..."
QT_MOC_LITERAL(24, 301, 29), // "on_Storage_pushButton_clicked"
QT_MOC_LITERAL(25, 331, 27), // "on_Floor_pushButton_clicked"
QT_MOC_LITERAL(26, 359, 34), // "on_Picture_Path_pushButton_cl..."
QT_MOC_LITERAL(27, 394, 35), // "on_Picture_Label_pushButton_c..."
QT_MOC_LITERAL(28, 430, 33) // "on_Object_Type_pushButton_cli..."

    },
    "SearchWin\0ObjectLabel\0\0label\0ObjectName\0"
    "name\0ObjectType\0Type\0ObjectDate\0from\0"
    "to\0ObjectDueDate\0date\0StorageLabel\0"
    "FloorLabel\0sto\0flo\0PicturePath\0path\0"
    "PictureLabel\0on_Object_Label_pushButton_clicked\0"
    "on_Object_Name_pushButton_clicked\0"
    "on_Object_Date_pushButton_clicked\0"
    "on_Object_DueDate_pushButton_clicked\0"
    "on_Storage_pushButton_clicked\0"
    "on_Floor_pushButton_clicked\0"
    "on_Picture_Path_pushButton_clicked\0"
    "on_Picture_Label_pushButton_clicked\0"
    "on_Object_Type_pushButton_clicked"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_SearchWin[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      18,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       9,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,  104,    2, 0x06 /* Public */,
       4,    1,  107,    2, 0x06 /* Public */,
       6,    1,  110,    2, 0x06 /* Public */,
       8,    2,  113,    2, 0x06 /* Public */,
      11,    1,  118,    2, 0x06 /* Public */,
      13,    1,  121,    2, 0x06 /* Public */,
      14,    2,  124,    2, 0x06 /* Public */,
      17,    1,  129,    2, 0x06 /* Public */,
      19,    1,  132,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
      20,    0,  135,    2, 0x08 /* Private */,
      21,    0,  136,    2, 0x08 /* Private */,
      22,    0,  137,    2, 0x08 /* Private */,
      23,    0,  138,    2, 0x08 /* Private */,
      24,    0,  139,    2, 0x08 /* Private */,
      25,    0,  140,    2, 0x08 /* Private */,
      26,    0,  141,    2, 0x08 /* Private */,
      27,    0,  142,    2, 0x08 /* Private */,
      28,    0,  143,    2, 0x08 /* Private */,

 // signals: parameters
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void, QMetaType::QString,    5,
    QMetaType::Void, QMetaType::QString,    7,
    QMetaType::Void, QMetaType::Int, QMetaType::Int,    9,   10,
    QMetaType::Void, QMetaType::Int,   12,
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void, QMetaType::Int, QMetaType::Int,   15,   16,
    QMetaType::Void, QMetaType::QString,   18,
    QMetaType::Void, QMetaType::Int,    3,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void SearchWin::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<SearchWin *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->ObjectLabel((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 1: _t->ObjectName((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 2: _t->ObjectType((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 3: _t->ObjectDate((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 4: _t->ObjectDueDate((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 5: _t->StorageLabel((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 6: _t->FloorLabel((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 7: _t->PicturePath((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 8: _t->PictureLabel((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 9: _t->on_Object_Label_pushButton_clicked(); break;
        case 10: _t->on_Object_Name_pushButton_clicked(); break;
        case 11: _t->on_Object_Date_pushButton_clicked(); break;
        case 12: _t->on_Object_DueDate_pushButton_clicked(); break;
        case 13: _t->on_Storage_pushButton_clicked(); break;
        case 14: _t->on_Floor_pushButton_clicked(); break;
        case 15: _t->on_Picture_Path_pushButton_clicked(); break;
        case 16: _t->on_Picture_Label_pushButton_clicked(); break;
        case 17: _t->on_Object_Type_pushButton_clicked(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (SearchWin::*)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&SearchWin::ObjectLabel)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (SearchWin::*)(QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&SearchWin::ObjectName)) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (SearchWin::*)(QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&SearchWin::ObjectType)) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (SearchWin::*)(int , int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&SearchWin::ObjectDate)) {
                *result = 3;
                return;
            }
        }
        {
            using _t = void (SearchWin::*)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&SearchWin::ObjectDueDate)) {
                *result = 4;
                return;
            }
        }
        {
            using _t = void (SearchWin::*)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&SearchWin::StorageLabel)) {
                *result = 5;
                return;
            }
        }
        {
            using _t = void (SearchWin::*)(int , int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&SearchWin::FloorLabel)) {
                *result = 6;
                return;
            }
        }
        {
            using _t = void (SearchWin::*)(QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&SearchWin::PicturePath)) {
                *result = 7;
                return;
            }
        }
        {
            using _t = void (SearchWin::*)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&SearchWin::PictureLabel)) {
                *result = 8;
                return;
            }
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject SearchWin::staticMetaObject = { {
    QMetaObject::SuperData::link<QDialog::staticMetaObject>(),
    qt_meta_stringdata_SearchWin.data,
    qt_meta_data_SearchWin,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *SearchWin::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *SearchWin::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_SearchWin.stringdata0))
        return static_cast<void*>(this);
    return QDialog::qt_metacast(_clname);
}

int SearchWin::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QDialog::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 18)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 18;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 18)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 18;
    }
    return _id;
}

// SIGNAL 0
void SearchWin::ObjectLabel(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void SearchWin::ObjectName(QString _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void SearchWin::ObjectType(QString _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void SearchWin::ObjectDate(int _t1, int _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}

// SIGNAL 4
void SearchWin::ObjectDueDate(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 4, _a);
}

// SIGNAL 5
void SearchWin::StorageLabel(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 5, _a);
}

// SIGNAL 6
void SearchWin::FloorLabel(int _t1, int _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))) };
    QMetaObject::activate(this, &staticMetaObject, 6, _a);
}

// SIGNAL 7
void SearchWin::PicturePath(QString _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 7, _a);
}

// SIGNAL 8
void SearchWin::PictureLabel(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 8, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
