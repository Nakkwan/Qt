/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.14.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../DepotManagement/mainwindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.14.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_MainWindow_t {
    QByteArrayData data[49];
    char stringdata0[1144];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MainWindow_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
QT_MOC_LITERAL(0, 0, 10), // "MainWindow"
QT_MOC_LITERAL(1, 11, 15), // "SendPicturePath"
QT_MOC_LITERAL(2, 27, 0), // ""
QT_MOC_LITERAL(3, 28, 4), // "path"
QT_MOC_LITERAL(4, 33, 25), // "on_actionSearch_triggered"
QT_MOC_LITERAL(5, 59, 30), // "on_Item_Add_pushButton_clicked"
QT_MOC_LITERAL(6, 90, 33), // "on_Display_All_pushButton_cli..."
QT_MOC_LITERAL(7, 124, 27), // "on_Clear_pushButton_clicked"
QT_MOC_LITERAL(8, 152, 33), // "on_Storage_Add_pushButton_cli..."
QT_MOC_LITERAL(9, 186, 41), // "on_Storage_Update_Load_pushBu..."
QT_MOC_LITERAL(10, 228, 36), // "on_Storage_Update_pushButton_..."
QT_MOC_LITERAL(11, 265, 36), // "on_Storage_Delete_pushButton_..."
QT_MOC_LITERAL(12, 302, 31), // "on_Floor_Add_pushButton_clicked"
QT_MOC_LITERAL(13, 334, 39), // "on_Floor_Update_Load_pushButt..."
QT_MOC_LITERAL(14, 374, 34), // "on_Floor_Update_pushButton_cl..."
QT_MOC_LITERAL(15, 409, 34), // "on_Floor_Delete_pushButton_cl..."
QT_MOC_LITERAL(16, 444, 30), // "on_Food_Add_pushButton_clicked"
QT_MOC_LITERAL(17, 475, 33), // "on_Item_Delete_pushButton_cli..."
QT_MOC_LITERAL(18, 509, 33), // "on_Item_Update_pushButton_cli..."
QT_MOC_LITERAL(19, 543, 38), // "on_Item_Add_Picture_pushButto..."
QT_MOC_LITERAL(20, 582, 38), // "on_Item_Update_Load_pushButto..."
QT_MOC_LITERAL(21, 621, 38), // "on_Food_Add_Picture_pushButto..."
QT_MOC_LITERAL(22, 660, 41), // "on_Item_Update_Picture_pushBu..."
QT_MOC_LITERAL(23, 702, 31), // "on_actionHeirarchical_triggered"
QT_MOC_LITERAL(24, 734, 28), // "on_actionTemp_List_triggered"
QT_MOC_LITERAL(25, 763, 31), // "on_actionTemp_Dequeue_triggered"
QT_MOC_LITERAL(26, 795, 30), // "on_actionRecent_List_triggered"
QT_MOC_LITERAL(27, 826, 31), // "on_actionLocationSave_triggered"
QT_MOC_LITERAL(28, 858, 27), // "on_actionItemSave_triggered"
QT_MOC_LITERAL(29, 886, 27), // "on_actionItemLoad_triggered"
QT_MOC_LITERAL(30, 914, 31), // "on_actionLocationLoad_triggered"
QT_MOC_LITERAL(31, 946, 25), // "on_actionManual_triggered"
QT_MOC_LITERAL(32, 972, 14), // "GetObjectLabel"
QT_MOC_LITERAL(33, 987, 5), // "label"
QT_MOC_LITERAL(34, 993, 13), // "GetObjectName"
QT_MOC_LITERAL(35, 1007, 4), // "name"
QT_MOC_LITERAL(36, 1012, 13), // "GetObjectType"
QT_MOC_LITERAL(37, 1026, 4), // "type"
QT_MOC_LITERAL(38, 1031, 13), // "GetObjectDate"
QT_MOC_LITERAL(39, 1045, 4), // "from"
QT_MOC_LITERAL(40, 1050, 2), // "to"
QT_MOC_LITERAL(41, 1053, 16), // "GetObjectDueDate"
QT_MOC_LITERAL(42, 1070, 4), // "date"
QT_MOC_LITERAL(43, 1075, 15), // "GetStorageLabel"
QT_MOC_LITERAL(44, 1091, 13), // "GetFloorLabel"
QT_MOC_LITERAL(45, 1105, 3), // "sto"
QT_MOC_LITERAL(46, 1109, 3), // "flo"
QT_MOC_LITERAL(47, 1113, 14), // "GetPicturePath"
QT_MOC_LITERAL(48, 1128, 15) // "GetPictureLabel"

    },
    "MainWindow\0SendPicturePath\0\0path\0"
    "on_actionSearch_triggered\0"
    "on_Item_Add_pushButton_clicked\0"
    "on_Display_All_pushButton_clicked\0"
    "on_Clear_pushButton_clicked\0"
    "on_Storage_Add_pushButton_clicked\0"
    "on_Storage_Update_Load_pushButton_clicked\0"
    "on_Storage_Update_pushButton_clicked\0"
    "on_Storage_Delete_pushButton_clicked\0"
    "on_Floor_Add_pushButton_clicked\0"
    "on_Floor_Update_Load_pushButton_clicked\0"
    "on_Floor_Update_pushButton_clicked\0"
    "on_Floor_Delete_pushButton_clicked\0"
    "on_Food_Add_pushButton_clicked\0"
    "on_Item_Delete_pushButton_clicked\0"
    "on_Item_Update_pushButton_clicked\0"
    "on_Item_Add_Picture_pushButton_clicked\0"
    "on_Item_Update_Load_pushButton_clicked\0"
    "on_Food_Add_Picture_pushButton_clicked\0"
    "on_Item_Update_Picture_pushButton_clicked\0"
    "on_actionHeirarchical_triggered\0"
    "on_actionTemp_List_triggered\0"
    "on_actionTemp_Dequeue_triggered\0"
    "on_actionRecent_List_triggered\0"
    "on_actionLocationSave_triggered\0"
    "on_actionItemSave_triggered\0"
    "on_actionItemLoad_triggered\0"
    "on_actionLocationLoad_triggered\0"
    "on_actionManual_triggered\0GetObjectLabel\0"
    "label\0GetObjectName\0name\0GetObjectType\0"
    "type\0GetObjectDate\0from\0to\0GetObjectDueDate\0"
    "date\0GetStorageLabel\0GetFloorLabel\0"
    "sto\0flo\0GetPicturePath\0GetPictureLabel"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MainWindow[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      38,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       1,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,  204,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       4,    0,  207,    2, 0x08 /* Private */,
       5,    0,  208,    2, 0x08 /* Private */,
       6,    0,  209,    2, 0x08 /* Private */,
       7,    0,  210,    2, 0x08 /* Private */,
       8,    0,  211,    2, 0x08 /* Private */,
       9,    0,  212,    2, 0x08 /* Private */,
      10,    0,  213,    2, 0x08 /* Private */,
      11,    0,  214,    2, 0x08 /* Private */,
      12,    0,  215,    2, 0x08 /* Private */,
      13,    0,  216,    2, 0x08 /* Private */,
      14,    0,  217,    2, 0x08 /* Private */,
      15,    0,  218,    2, 0x08 /* Private */,
      16,    0,  219,    2, 0x08 /* Private */,
      17,    0,  220,    2, 0x08 /* Private */,
      18,    0,  221,    2, 0x08 /* Private */,
      19,    0,  222,    2, 0x08 /* Private */,
      20,    0,  223,    2, 0x08 /* Private */,
      21,    0,  224,    2, 0x08 /* Private */,
      22,    0,  225,    2, 0x08 /* Private */,
      23,    0,  226,    2, 0x08 /* Private */,
      24,    0,  227,    2, 0x08 /* Private */,
      25,    0,  228,    2, 0x08 /* Private */,
      26,    0,  229,    2, 0x08 /* Private */,
      27,    0,  230,    2, 0x08 /* Private */,
      28,    0,  231,    2, 0x08 /* Private */,
      29,    0,  232,    2, 0x08 /* Private */,
      30,    0,  233,    2, 0x08 /* Private */,
      31,    0,  234,    2, 0x08 /* Private */,
      32,    1,  235,    2, 0x0a /* Public */,
      34,    1,  238,    2, 0x0a /* Public */,
      36,    1,  241,    2, 0x0a /* Public */,
      38,    2,  244,    2, 0x0a /* Public */,
      41,    1,  249,    2, 0x0a /* Public */,
      43,    1,  252,    2, 0x0a /* Public */,
      44,    2,  255,    2, 0x0a /* Public */,
      47,    1,  260,    2, 0x0a /* Public */,
      48,    1,  263,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void, QMetaType::QString,    3,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   33,
    QMetaType::Void, QMetaType::QString,   35,
    QMetaType::Void, QMetaType::QString,   37,
    QMetaType::Void, QMetaType::Int, QMetaType::Int,   39,   40,
    QMetaType::Void, QMetaType::Int,   42,
    QMetaType::Void, QMetaType::Int,   33,
    QMetaType::Void, QMetaType::Int, QMetaType::Int,   45,   46,
    QMetaType::Void, QMetaType::QString,    3,
    QMetaType::Void, QMetaType::Int,   33,

       0        // eod
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<MainWindow *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->SendPicturePath((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 1: _t->on_actionSearch_triggered(); break;
        case 2: _t->on_Item_Add_pushButton_clicked(); break;
        case 3: _t->on_Display_All_pushButton_clicked(); break;
        case 4: _t->on_Clear_pushButton_clicked(); break;
        case 5: _t->on_Storage_Add_pushButton_clicked(); break;
        case 6: _t->on_Storage_Update_Load_pushButton_clicked(); break;
        case 7: _t->on_Storage_Update_pushButton_clicked(); break;
        case 8: _t->on_Storage_Delete_pushButton_clicked(); break;
        case 9: _t->on_Floor_Add_pushButton_clicked(); break;
        case 10: _t->on_Floor_Update_Load_pushButton_clicked(); break;
        case 11: _t->on_Floor_Update_pushButton_clicked(); break;
        case 12: _t->on_Floor_Delete_pushButton_clicked(); break;
        case 13: _t->on_Food_Add_pushButton_clicked(); break;
        case 14: _t->on_Item_Delete_pushButton_clicked(); break;
        case 15: _t->on_Item_Update_pushButton_clicked(); break;
        case 16: _t->on_Item_Add_Picture_pushButton_clicked(); break;
        case 17: _t->on_Item_Update_Load_pushButton_clicked(); break;
        case 18: _t->on_Food_Add_Picture_pushButton_clicked(); break;
        case 19: _t->on_Item_Update_Picture_pushButton_clicked(); break;
        case 20: _t->on_actionHeirarchical_triggered(); break;
        case 21: _t->on_actionTemp_List_triggered(); break;
        case 22: _t->on_actionTemp_Dequeue_triggered(); break;
        case 23: _t->on_actionRecent_List_triggered(); break;
        case 24: _t->on_actionLocationSave_triggered(); break;
        case 25: _t->on_actionItemSave_triggered(); break;
        case 26: _t->on_actionItemLoad_triggered(); break;
        case 27: _t->on_actionLocationLoad_triggered(); break;
        case 28: _t->on_actionManual_triggered(); break;
        case 29: _t->GetObjectLabel((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 30: _t->GetObjectName((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 31: _t->GetObjectType((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 32: _t->GetObjectDate((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 33: _t->GetObjectDueDate((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 34: _t->GetStorageLabel((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 35: _t->GetFloorLabel((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 36: _t->GetPicturePath((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 37: _t->GetPictureLabel((*reinterpret_cast< int(*)>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (MainWindow::*)(QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::SendPicturePath)) {
                *result = 0;
                return;
            }
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject MainWindow::staticMetaObject = { {
    QMetaObject::SuperData::link<QMainWindow::staticMetaObject>(),
    qt_meta_stringdata_MainWindow.data,
    qt_meta_data_MainWindow,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata0))
        return static_cast<void*>(this);
    if (!strcmp(_clname, "Base"))
        return static_cast< Base*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 38)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 38;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 38)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 38;
    }
    return _id;
}

// SIGNAL 0
void MainWindow::SendPicturePath(QString _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
