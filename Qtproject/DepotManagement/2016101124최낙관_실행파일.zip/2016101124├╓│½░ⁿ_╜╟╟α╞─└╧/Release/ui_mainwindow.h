/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.14.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenu>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPlainTextEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QTextBrowser>
#include <QtWidgets/QTreeView>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QAction *actionItemSave;
    QAction *actionLocationSave;
    QAction *actionSearch;
    QAction *actionRecent_List;
    QAction *actionTemp_List;
    QAction *actionHeirarchical;
    QAction *actionTemp_Dequeue;
    QAction *actionItemLoad;
    QAction *actionLocationLoad;
    QAction *actionManual;
    QWidget *centralwidget;
    QTabWidget *Item_tabWidget;
    QWidget *Item_Add;
    QHBoxLayout *horizontalLayout_12;
    QVBoxLayout *verticalLayout_2;
    QHBoxLayout *horizontalLayout_6;
    QVBoxLayout *verticalLayout_3;
    QLabel *label;
    QLabel *label_2;
    QLabel *label_3;
    QLabel *label_4;
    QLabel *label_8;
    QLabel *label_9;
    QVBoxLayout *verticalLayout;
    QPlainTextEdit *Item_Add_Name_plainTextEdit;
    QPlainTextEdit *Item_Add_type_plainTextEdit;
    QSpinBox *Item_Add_Num_spinBox;
    QPlainTextEdit *Item_Add_Date_plainTextEdit;
    QHBoxLayout *horizontalLayout_2;
    QRadioButton *Item_Add_Yes_radioButton;
    QRadioButton *Item_Add_No_radioButton;
    QHBoxLayout *horizontalLayout;
    QPlainTextEdit *Item_Add_Picture_plainTextEdit;
    QPushButton *Item_Add_Picture_pushButton;
    QVBoxLayout *verticalLayout_6;
    QHBoxLayout *horizontalLayout_3;
    QLabel *label_5;
    QHBoxLayout *horizontalLayout_4;
    QVBoxLayout *verticalLayout_4;
    QLabel *label_6;
    QLabel *label_7;
    QVBoxLayout *verticalLayout_5;
    QPlainTextEdit *Item_Add_Storage_plainTextEdit;
    QPlainTextEdit *Item_Add_Floor_plainTextEdit;
    QHBoxLayout *horizontalLayout_5;
    QSpacerItem *horizontalSpacer;
    QPushButton *Item_Add_pushButton;
    QSpacerItem *horizontalSpacer_2;
    QWidget *Food_Add;
    QHBoxLayout *horizontalLayout_15;
    QVBoxLayout *verticalLayout_13;
    QHBoxLayout *horizontalLayout_14;
    QVBoxLayout *verticalLayout_36;
    QLabel *label_34;
    QLabel *label_35;
    QLabel *label_36;
    QLabel *label_37;
    QLabel *label_38;
    QLabel *label_13;
    QVBoxLayout *verticalLayout_7;
    QPlainTextEdit *Food_Add_Name_plainTextEdit;
    QPlainTextEdit *Food_Add_Type_plainTextEdit;
    QSpinBox *Food_Add_Num_spinBox;
    QPlainTextEdit *Food_Add_Date_plainTextEdit;
    QPlainTextEdit *Food_Add_DueDate_plainTextEdit;
    QHBoxLayout *horizontalLayout_13;
    QPlainTextEdit *Food_Add_Picture_plainTextEdit;
    QPushButton *Food_Add_Picture_pushButton;
    QVBoxLayout *verticalLayout_38;
    QHBoxLayout *horizontalLayout_36;
    QLabel *label_39;
    QHBoxLayout *horizontalLayout_37;
    QVBoxLayout *verticalLayout_39;
    QLabel *label_40;
    QLabel *label_41;
    QVBoxLayout *verticalLayout_40;
    QPlainTextEdit *Food_Add_Storage_plainTextEdit;
    QPlainTextEdit *Food_Add_Floor_plainTextEdit;
    QHBoxLayout *horizontalLayout_38;
    QSpacerItem *horizontalSpacer_22;
    QPushButton *Food_Add_pushButton;
    QSpacerItem *horizontalSpacer_23;
    QWidget *Item_Delete;
    QVBoxLayout *verticalLayout_42;
    QVBoxLayout *verticalLayout_41;
    QHBoxLayout *horizontalLayout_35;
    QLabel *label_43;
    QPlainTextEdit *Item_Delete_plainTextEdit;
    QHBoxLayout *horizontalLayout_39;
    QSpacerItem *horizontalSpacer_24;
    QPushButton *Item_Delete_pushButton;
    QSpacerItem *horizontalSpacer_25;
    QLabel *label_44;
    QSpacerItem *verticalSpacer_6;
    QWidget *Item_Update;
    QHBoxLayout *horizontalLayout_29;
    QVBoxLayout *verticalLayout_30;
    QHBoxLayout *horizontalLayout_28;
    QLabel *label_33;
    QPlainTextEdit *Item_Update_Label_plainTextEdit;
    QPushButton *Item_Update_Load_pushButton;
    QHBoxLayout *horizontalLayout_26;
    QVBoxLayout *verticalLayout_31;
    QLabel *label_27;
    QLabel *label_29;
    QLabel *label_30;
    QLabel *label_31;
    QLabel *label_32;
    QLabel *label_42;
    QLabel *label_14;
    QVBoxLayout *verticalLayout_32;
    QPlainTextEdit *Item_Update_Name_plainTextEdit;
    QPlainTextEdit *Item_Update_Type_plainTextEdit;
    QSpinBox *Item_Update_Num_spinBox;
    QPlainTextEdit *Item_Update_Date_plainTextEdit;
    QHBoxLayout *horizontalLayout_27;
    QRadioButton *Item_Update_Yes_radioButton;
    QRadioButton *Item_Update_No_radioButton;
    QPlainTextEdit *Item_Update_DueDate_plainTextEdit;
    QHBoxLayout *horizontalLayout_16;
    QPlainTextEdit *Item_Update_Picture_plainTextEdit;
    QPushButton *Item_Update_Picture_pushButton;
    QSpacerItem *verticalSpacer_8;
    QHBoxLayout *horizontalLayout_30;
    QSpacerItem *horizontalSpacer_15;
    QPushButton *Item_Update_pushButton;
    QSpacerItem *horizontalSpacer_16;
    QTabWidget *Storage_tabWidget;
    QWidget *Storage_Add;
    QHBoxLayout *horizontalLayout_9;
    QVBoxLayout *verticalLayout_10;
    QHBoxLayout *horizontalLayout_7;
    QVBoxLayout *verticalLayout_8;
    QLabel *label_15;
    QLabel *label_10;
    QLabel *label_11;
    QVBoxLayout *verticalLayout_9;
    QPlainTextEdit *Storage_Add_Label_plainTextEdit;
    QPlainTextEdit *Storage_Add_Type_plainTextEdit;
    QPlainTextEdit *Storage_Add_Floor_plainTextEdit;
    QHBoxLayout *horizontalLayout_8;
    QSpacerItem *horizontalSpacer_3;
    QPushButton *Storage_Add_pushButton;
    QSpacerItem *horizontalSpacer_4;
    QWidget *Storage_Update;
    QHBoxLayout *horizontalLayout_18;
    QHBoxLayout *horizontalLayout_17;
    QVBoxLayout *verticalLayout_18;
    QLabel *label_17;
    QLabel *label_19;
    QLabel *label_20;
    QVBoxLayout *verticalLayout_19;
    QPlainTextEdit *Storage_Update_Label_plainTextEdit;
    QPlainTextEdit *Storage_Update_Type_plainTextEdit;
    QTextBrowser *Storage_Update_Floor_textBrowser;
    QVBoxLayout *verticalLayout_20;
    QPushButton *Storage_Update_Load_pushButton;
    QSpacerItem *verticalSpacer_3;
    QPushButton *Storage_Update_pushButton;
    QWidget *Storage_Delete;
    QVBoxLayout *verticalLayout_12;
    QVBoxLayout *verticalLayout_11;
    QHBoxLayout *horizontalLayout_10;
    QLabel *label_12;
    QPlainTextEdit *Storage_Delete_Label_plainTextEdit;
    QHBoxLayout *horizontalLayout_11;
    QSpacerItem *horizontalSpacer_5;
    QPushButton *Storage_Delete_pushButton;
    QSpacerItem *horizontalSpacer_6;
    QSpacerItem *verticalSpacer;
    QWidget *Floor_Add;
    QHBoxLayout *horizontalLayout_21;
    QVBoxLayout *verticalLayout_23;
    QHBoxLayout *horizontalLayout_20;
    QVBoxLayout *verticalLayout_22;
    QLabel *label_21;
    QLabel *label_22;
    QVBoxLayout *verticalLayout_21;
    QPlainTextEdit *Floor_Add_StorageLabel_plainTextEdit;
    QPlainTextEdit *Floor_Add_Type_plainTextEdit;
    QHBoxLayout *horizontalLayout_19;
    QSpacerItem *horizontalSpacer_11;
    QPushButton *Floor_Add_pushButton;
    QSpacerItem *horizontalSpacer_12;
    QWidget *Floor_Update;
    QHBoxLayout *horizontalLayout_33;
    QVBoxLayout *verticalLayout_34;
    QHBoxLayout *horizontalLayout_24;
    QVBoxLayout *verticalLayout_27;
    QLabel *label_25;
    QLabel *label_28;
    QLabel *label_26;
    QVBoxLayout *verticalLayout_28;
    QPlainTextEdit *Floor_Update_StorageLabel_plainTextEdit;
    QPlainTextEdit *Floor_Update_Floor_plainTextEdit;
    QPlainTextEdit *Floor_Update_Type_plainTextEdit;
    QVBoxLayout *verticalLayout_29;
    QSpacerItem *verticalSpacer_5;
    QPushButton *Floor_Update_Load_pushButton;
    QSpacerItem *verticalSpacer_4;
    QHBoxLayout *horizontalLayout_32;
    QSpacerItem *horizontalSpacer_20;
    QPushButton *Floor_Update_pushButton;
    QSpacerItem *horizontalSpacer_21;
    QWidget *Floor_Delete;
    QHBoxLayout *horizontalLayout_25;
    QVBoxLayout *verticalLayout_24;
    QHBoxLayout *horizontalLayout_22;
    QVBoxLayout *verticalLayout_25;
    QLabel *label_23;
    QLabel *label_24;
    QVBoxLayout *verticalLayout_26;
    QPlainTextEdit *Floor_Delete_StorageLabel_plainTextEdit;
    QPlainTextEdit *Floor_Delete_Floor_plainTextEdit;
    QHBoxLayout *horizontalLayout_23;
    QSpacerItem *horizontalSpacer_13;
    QPushButton *Floor_Delete_pushButton;
    QSpacerItem *horizontalSpacer_14;
    QWidget *layoutWidget;
    QVBoxLayout *verticalLayout_33;
    QTreeView *treeView;
    QHBoxLayout *horizontalLayout_31;
    QSpacerItem *horizontalSpacer_17;
    QPushButton *Display_All_pushButton;
    QSpacerItem *horizontalSpacer_18;
    QPushButton *Clear_pushButton;
    QSpacerItem *horizontalSpacer_19;
    QLabel *Main_Info_label;
    QMenuBar *menubar;
    QMenu *menu_4;
    QMenu *menuDisplay;
    QMenu *menu_5;
    QMenu *menuHelp;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(1093, 811);
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(MainWindow->sizePolicy().hasHeightForWidth());
        MainWindow->setSizePolicy(sizePolicy);
        MainWindow->setMinimumSize(QSize(0, 0));
        MainWindow->setStyleSheet(QString::fromUtf8("*{	\n"
"}\n"
"\n"
"QMainWindow::title{\n"
"	color: white;\n"
"}\n"
"QMenuBar{\n"
"	background-image: url(:/images/images/background2.png);\n"
"}\n"
"QMenu{\n"
"	\n"
"	background-color: rgba(95, 170, 245, 240);\n"
"	border-radius: 5px;\n"
"}\n"
"QMenuBar::item:selected{\n"
"	background-color: rgba(95, 170, 245, 240);\n"
"	border-top-left-radius: 5px;\n"
"	border-top-right-radius: 5px;\n"
"	color:white;\n"
"}\n"
"QMenuBar::item{\n"
"	border-style: solid;\n"
"	border-bottom-width: 1px;\n"
"	padding: 5px;\n"
"	padding-left: 10px;\n"
"	padding-right: 10px;\n"
"	color:black;\n"
"}\n"
"\n"
"QMenuBar:pressed{\n"
"	color:black;\n"
"}\n"
"\n"
"QMainWindow{\n"
"	background-image: url(:/images/images/Back2.png);\n"
"}\n"
"QTreeView{\n"
"	border-radius: 10px;\n"
"	/*background-color: rgba(210, 240, 255, 150);*/\n"
"	background-color: rgba(160, 200, 255, 100);\n"
"}\n"
"QPushButton{\n"
"	background-color: rgba(120, 160, 255, 180);\n"
"	border-style: hidden;\n"
"	border-radius: 2px 7px;\n"
"	border-width: 1px\n"
"}\n"
"QPush"
                        "Button:pressed{\n"
"	background-color: rgba(100, 120, 255, 180);\n"
"}\n"
"QTabBar::tab{\n"
"	background-color: rgba(120, 160, 255, 180);\n"
"	border-top-left-radius: 5px;\n"
"	border-top-right-radius: 5px;\n"
"	background-color: rgba(120, 160, 255, 180);\n"
"	border-style: solid;\n"
"	border-width: 1px;\n"
"	padding-top: 5px;\n"
"	padding-bottom: 5px;\n"
"	padding-left: 15px;\n"
"	padding-right: 15px;\n"
"}\n"
"QTabBar::tab:selected{\n"
"	/*background-color: rgba(190, 220, 255, 200);*/\n"
"	background-color: rgba(160, 200, 255, 180);\n"
"	border-radius: 5px;\n"
"	padding: 5px;\n"
"	margin-bottom: -1px;\n"
"	border-style: solid;\n"
"	border-top-color: rgba(255, 255, 255, 150);\n"
"	border-left-color: rgba(255, 255, 255, 150);\n"
"	border-right-color: rgba(255, 255, 255, 150);\n"
"	border-bottom-color: rgba(255, 255, 255, 150);\n"
"	padding-top: 5px;\n"
"	padding-bottom: 5px;\n"
"	padding-left: 15px;\n"
"	padding-right: 15px;\n"
"}\n"
"QTabWidget::pane{\n"
"	/*background-color: rgba(190, 220, 255, 200);*/\n"
"	"
                        "background-color: rgba(160, 200, 255, 180);\n"
"	border-bottom-left-radius: 5px;\n"
"	border-bottom-right-radius: 5px;\n"
"	border-top-right-radius: 5px;\n"
"	border-style: solid;\n"
"	border-width: 1px;\n"
"	border-color: rgba(255, 255, 255, 150);\n"
"	padding: 5px;\n"
"	margin-top: -1px;	\n"
"}\n"
"QPlainTextEdit:focus{\n"
"	border-radius: 20px;\n"
"	border-style: solid;\n"
"	border-color:white;\n"
"}\n"
"QPlainTextEdit{\n"
"	border-radius: 20px;\n"
"	border-style: solid;\n"
"	border-color:white;\n"
"}\n"
"QSpinBox{\n"
"	border-style: hide;	\n"
"	border-image: none;\n"
"}\n"
"QSpinBox::up-arrow {\n"
"	image: url(:/images/images/UpArrow.png);\n"
"    width: 15px;\n"
"    height: 15px;\n"
"}\n"
"QSpinBox::up-button {\n"
"    border-image: none;\n"
"    border-width: 2px;\n"
"}\n"
"QSpinBox::down-arrow {\n"
"	\n"
"	image: url(:/images/images/DownArrow.png);\n"
"    width: 15px;\n"
"    height: 15px;\n"
"}\n"
"QSpinBox::down-button {\n"
"    border-image: none;\n"
"    border-width: 2px;\n"
"}\n"
"QTextBrowser{\n"
""
                        "	border-style: hide;\n"
"}\n"
"\n"
"QRadioButton::indicator {\n"
"    width: 30px;\n"
"    height: 30px;\n"
"}\n"
"\n"
"\n"
"QRadioButton::indicator::unchecked {\n"
"	image: url(:/images/images/check_before.png);\n"
"}\n"
"\n"
"QRadioButton::indicator:unchecked:hover {\n"
"	image: url(:/images/images/check_before.png);\n"
"}\n"
"\n"
"QRadioButton::indicator::checked {\n"
"    image: url(:/images/images/check_after.png);\n"
"}\n"
"\n"
"QRadioButton::indicator:checked:hover {\n"
"    image: url(:/images/images/check_after.png);\n"
"}\n"
"\n"
""));
        actionItemSave = new QAction(MainWindow);
        actionItemSave->setObjectName(QString::fromUtf8("actionItemSave"));
        actionLocationSave = new QAction(MainWindow);
        actionLocationSave->setObjectName(QString::fromUtf8("actionLocationSave"));
        actionSearch = new QAction(MainWindow);
        actionSearch->setObjectName(QString::fromUtf8("actionSearch"));
        actionRecent_List = new QAction(MainWindow);
        actionRecent_List->setObjectName(QString::fromUtf8("actionRecent_List"));
        actionTemp_List = new QAction(MainWindow);
        actionTemp_List->setObjectName(QString::fromUtf8("actionTemp_List"));
        actionHeirarchical = new QAction(MainWindow);
        actionHeirarchical->setObjectName(QString::fromUtf8("actionHeirarchical"));
        actionTemp_Dequeue = new QAction(MainWindow);
        actionTemp_Dequeue->setObjectName(QString::fromUtf8("actionTemp_Dequeue"));
        actionItemLoad = new QAction(MainWindow);
        actionItemLoad->setObjectName(QString::fromUtf8("actionItemLoad"));
        actionLocationLoad = new QAction(MainWindow);
        actionLocationLoad->setObjectName(QString::fromUtf8("actionLocationLoad"));
        actionManual = new QAction(MainWindow);
        actionManual->setObjectName(QString::fromUtf8("actionManual"));
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        Item_tabWidget = new QTabWidget(centralwidget);
        Item_tabWidget->setObjectName(QString::fromUtf8("Item_tabWidget"));
        Item_tabWidget->setGeometry(QRect(30, 10, 556, 479));
        Item_tabWidget->setStyleSheet(QString::fromUtf8(""));
        Item_Add = new QWidget();
        Item_Add->setObjectName(QString::fromUtf8("Item_Add"));
        horizontalLayout_12 = new QHBoxLayout(Item_Add);
        horizontalLayout_12->setObjectName(QString::fromUtf8("horizontalLayout_12"));
        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        horizontalLayout_6 = new QHBoxLayout();
        horizontalLayout_6->setObjectName(QString::fromUtf8("horizontalLayout_6"));
        verticalLayout_3 = new QVBoxLayout();
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        label = new QLabel(Item_Add);
        label->setObjectName(QString::fromUtf8("label"));
        label->setMinimumSize(QSize(80, 30));
        label->setMaximumSize(QSize(80, 35));
        QFont font;
        font.setPointSize(10);
        label->setFont(font);
        label->setAlignment(Qt::AlignCenter);

        verticalLayout_3->addWidget(label);

        label_2 = new QLabel(Item_Add);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setMinimumSize(QSize(80, 30));
        label_2->setMaximumSize(QSize(80, 35));
        label_2->setFont(font);
        label_2->setAlignment(Qt::AlignCenter);

        verticalLayout_3->addWidget(label_2);

        label_3 = new QLabel(Item_Add);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setMinimumSize(QSize(80, 30));
        label_3->setMaximumSize(QSize(80, 35));
        label_3->setFont(font);
        label_3->setAlignment(Qt::AlignCenter);

        verticalLayout_3->addWidget(label_3);

        label_4 = new QLabel(Item_Add);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setMinimumSize(QSize(80, 30));
        label_4->setMaximumSize(QSize(80, 35));
        label_4->setFont(font);
        label_4->setAlignment(Qt::AlignCenter);

        verticalLayout_3->addWidget(label_4);

        label_8 = new QLabel(Item_Add);
        label_8->setObjectName(QString::fromUtf8("label_8"));
        label_8->setMinimumSize(QSize(80, 30));
        label_8->setMaximumSize(QSize(80, 35));
        label_8->setFont(font);
        label_8->setAlignment(Qt::AlignCenter);

        verticalLayout_3->addWidget(label_8);

        label_9 = new QLabel(Item_Add);
        label_9->setObjectName(QString::fromUtf8("label_9"));
        label_9->setMinimumSize(QSize(80, 30));
        label_9->setMaximumSize(QSize(80, 35));
        label_9->setAlignment(Qt::AlignCenter);

        verticalLayout_3->addWidget(label_9);


        horizontalLayout_6->addLayout(verticalLayout_3);

        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        Item_Add_Name_plainTextEdit = new QPlainTextEdit(Item_Add);
        Item_Add_Name_plainTextEdit->setObjectName(QString::fromUtf8("Item_Add_Name_plainTextEdit"));
        Item_Add_Name_plainTextEdit->setMinimumSize(QSize(430, 30));
        Item_Add_Name_plainTextEdit->setMaximumSize(QSize(500, 35));
        QFont font1;
        font1.setPointSize(11);
        Item_Add_Name_plainTextEdit->setFont(font1);

        verticalLayout->addWidget(Item_Add_Name_plainTextEdit);

        Item_Add_type_plainTextEdit = new QPlainTextEdit(Item_Add);
        Item_Add_type_plainTextEdit->setObjectName(QString::fromUtf8("Item_Add_type_plainTextEdit"));
        Item_Add_type_plainTextEdit->setMinimumSize(QSize(430, 30));
        Item_Add_type_plainTextEdit->setMaximumSize(QSize(500, 35));
        Item_Add_type_plainTextEdit->setFont(font1);

        verticalLayout->addWidget(Item_Add_type_plainTextEdit);

        Item_Add_Num_spinBox = new QSpinBox(Item_Add);
        Item_Add_Num_spinBox->setObjectName(QString::fromUtf8("Item_Add_Num_spinBox"));
        Item_Add_Num_spinBox->setMinimumSize(QSize(430, 35));
        Item_Add_Num_spinBox->setMaximumSize(QSize(500, 40));
        Item_Add_Num_spinBox->setFont(font1);

        verticalLayout->addWidget(Item_Add_Num_spinBox);

        Item_Add_Date_plainTextEdit = new QPlainTextEdit(Item_Add);
        Item_Add_Date_plainTextEdit->setObjectName(QString::fromUtf8("Item_Add_Date_plainTextEdit"));
        Item_Add_Date_plainTextEdit->setMinimumSize(QSize(430, 30));
        Item_Add_Date_plainTextEdit->setMaximumSize(QSize(500, 35));
        Item_Add_Date_plainTextEdit->setFont(font1);
        Item_Add_Date_plainTextEdit->setInputMethodHints(Qt::ImhMultiLine);

        verticalLayout->addWidget(Item_Add_Date_plainTextEdit);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        horizontalLayout_2->setSizeConstraint(QLayout::SetMinimumSize);
        Item_Add_Yes_radioButton = new QRadioButton(Item_Add);
        Item_Add_Yes_radioButton->setObjectName(QString::fromUtf8("Item_Add_Yes_radioButton"));
        Item_Add_Yes_radioButton->setMinimumSize(QSize(0, 35));
        Item_Add_Yes_radioButton->setMaximumSize(QSize(200, 35));
        Item_Add_Yes_radioButton->setFont(font);

        horizontalLayout_2->addWidget(Item_Add_Yes_radioButton);

        Item_Add_No_radioButton = new QRadioButton(Item_Add);
        Item_Add_No_radioButton->setObjectName(QString::fromUtf8("Item_Add_No_radioButton"));
        Item_Add_No_radioButton->setMinimumSize(QSize(0, 35));
        Item_Add_No_radioButton->setMaximumSize(QSize(200, 35));
        Item_Add_No_radioButton->setFont(font);

        horizontalLayout_2->addWidget(Item_Add_No_radioButton);


        verticalLayout->addLayout(horizontalLayout_2);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        Item_Add_Picture_plainTextEdit = new QPlainTextEdit(Item_Add);
        Item_Add_Picture_plainTextEdit->setObjectName(QString::fromUtf8("Item_Add_Picture_plainTextEdit"));
        Item_Add_Picture_plainTextEdit->setMinimumSize(QSize(320, 30));
        Item_Add_Picture_plainTextEdit->setMaximumSize(QSize(330, 35));
        Item_Add_Picture_plainTextEdit->setFont(font1);

        horizontalLayout->addWidget(Item_Add_Picture_plainTextEdit);

        Item_Add_Picture_pushButton = new QPushButton(Item_Add);
        Item_Add_Picture_pushButton->setObjectName(QString::fromUtf8("Item_Add_Picture_pushButton"));
        Item_Add_Picture_pushButton->setMinimumSize(QSize(100, 30));
        Item_Add_Picture_pushButton->setMaximumSize(QSize(100, 35));

        horizontalLayout->addWidget(Item_Add_Picture_pushButton);


        verticalLayout->addLayout(horizontalLayout);


        horizontalLayout_6->addLayout(verticalLayout);


        verticalLayout_2->addLayout(horizontalLayout_6);

        verticalLayout_6 = new QVBoxLayout();
        verticalLayout_6->setObjectName(QString::fromUtf8("verticalLayout_6"));
        verticalLayout_6->setContentsMargins(-1, -1, -1, 15);
        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        label_5 = new QLabel(Item_Add);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setMinimumSize(QSize(0, 30));
        label_5->setMaximumSize(QSize(16777215, 35));
        label_5->setFont(font1);
        label_5->setAlignment(Qt::AlignCenter);

        horizontalLayout_3->addWidget(label_5);


        verticalLayout_6->addLayout(horizontalLayout_3);

        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
        verticalLayout_4 = new QVBoxLayout();
        verticalLayout_4->setObjectName(QString::fromUtf8("verticalLayout_4"));
        label_6 = new QLabel(Item_Add);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setMinimumSize(QSize(80, 30));
        label_6->setMaximumSize(QSize(80, 35));
        label_6->setFont(font);
        label_6->setAlignment(Qt::AlignCenter);

        verticalLayout_4->addWidget(label_6);

        label_7 = new QLabel(Item_Add);
        label_7->setObjectName(QString::fromUtf8("label_7"));
        label_7->setMinimumSize(QSize(80, 30));
        label_7->setMaximumSize(QSize(80, 35));
        label_7->setFont(font);
        label_7->setAlignment(Qt::AlignCenter);

        verticalLayout_4->addWidget(label_7);


        horizontalLayout_4->addLayout(verticalLayout_4);

        verticalLayout_5 = new QVBoxLayout();
        verticalLayout_5->setObjectName(QString::fromUtf8("verticalLayout_5"));
        Item_Add_Storage_plainTextEdit = new QPlainTextEdit(Item_Add);
        Item_Add_Storage_plainTextEdit->setObjectName(QString::fromUtf8("Item_Add_Storage_plainTextEdit"));
        Item_Add_Storage_plainTextEdit->setMinimumSize(QSize(430, 30));
        Item_Add_Storage_plainTextEdit->setMaximumSize(QSize(500, 35));
        Item_Add_Storage_plainTextEdit->setFont(font1);

        verticalLayout_5->addWidget(Item_Add_Storage_plainTextEdit);

        Item_Add_Floor_plainTextEdit = new QPlainTextEdit(Item_Add);
        Item_Add_Floor_plainTextEdit->setObjectName(QString::fromUtf8("Item_Add_Floor_plainTextEdit"));
        Item_Add_Floor_plainTextEdit->setMinimumSize(QSize(430, 30));
        Item_Add_Floor_plainTextEdit->setMaximumSize(QSize(500, 35));
        Item_Add_Floor_plainTextEdit->setFont(font1);

        verticalLayout_5->addWidget(Item_Add_Floor_plainTextEdit);


        horizontalLayout_4->addLayout(verticalLayout_5);


        verticalLayout_6->addLayout(horizontalLayout_4);


        verticalLayout_2->addLayout(verticalLayout_6);

        horizontalLayout_5 = new QHBoxLayout();
        horizontalLayout_5->setObjectName(QString::fromUtf8("horizontalLayout_5"));
        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_5->addItem(horizontalSpacer);

        Item_Add_pushButton = new QPushButton(Item_Add);
        Item_Add_pushButton->setObjectName(QString::fromUtf8("Item_Add_pushButton"));
        Item_Add_pushButton->setMinimumSize(QSize(100, 30));
        Item_Add_pushButton->setMaximumSize(QSize(150, 35));

        horizontalLayout_5->addWidget(Item_Add_pushButton);

        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_5->addItem(horizontalSpacer_2);


        verticalLayout_2->addLayout(horizontalLayout_5);


        horizontalLayout_12->addLayout(verticalLayout_2);

        Item_tabWidget->addTab(Item_Add, QString());
        Food_Add = new QWidget();
        Food_Add->setObjectName(QString::fromUtf8("Food_Add"));
        horizontalLayout_15 = new QHBoxLayout(Food_Add);
        horizontalLayout_15->setObjectName(QString::fromUtf8("horizontalLayout_15"));
        verticalLayout_13 = new QVBoxLayout();
        verticalLayout_13->setObjectName(QString::fromUtf8("verticalLayout_13"));
        horizontalLayout_14 = new QHBoxLayout();
        horizontalLayout_14->setObjectName(QString::fromUtf8("horizontalLayout_14"));
        verticalLayout_36 = new QVBoxLayout();
        verticalLayout_36->setObjectName(QString::fromUtf8("verticalLayout_36"));
        label_34 = new QLabel(Food_Add);
        label_34->setObjectName(QString::fromUtf8("label_34"));
        label_34->setMinimumSize(QSize(80, 30));
        label_34->setMaximumSize(QSize(80, 35));
        label_34->setFont(font);
        label_34->setAlignment(Qt::AlignCenter);

        verticalLayout_36->addWidget(label_34);

        label_35 = new QLabel(Food_Add);
        label_35->setObjectName(QString::fromUtf8("label_35"));
        label_35->setMinimumSize(QSize(80, 30));
        label_35->setMaximumSize(QSize(80, 35));
        label_35->setFont(font);
        label_35->setAlignment(Qt::AlignCenter);

        verticalLayout_36->addWidget(label_35);

        label_36 = new QLabel(Food_Add);
        label_36->setObjectName(QString::fromUtf8("label_36"));
        label_36->setMinimumSize(QSize(80, 30));
        label_36->setMaximumSize(QSize(80, 35));
        label_36->setFont(font);
        label_36->setAlignment(Qt::AlignCenter);

        verticalLayout_36->addWidget(label_36);

        label_37 = new QLabel(Food_Add);
        label_37->setObjectName(QString::fromUtf8("label_37"));
        label_37->setMinimumSize(QSize(80, 30));
        label_37->setMaximumSize(QSize(80, 35));
        label_37->setFont(font);
        label_37->setAlignment(Qt::AlignCenter);

        verticalLayout_36->addWidget(label_37);

        label_38 = new QLabel(Food_Add);
        label_38->setObjectName(QString::fromUtf8("label_38"));
        label_38->setMinimumSize(QSize(80, 30));
        label_38->setMaximumSize(QSize(80, 35));
        label_38->setFont(font);
        label_38->setAlignment(Qt::AlignCenter);

        verticalLayout_36->addWidget(label_38);

        label_13 = new QLabel(Food_Add);
        label_13->setObjectName(QString::fromUtf8("label_13"));
        label_13->setMinimumSize(QSize(80, 30));
        label_13->setMaximumSize(QSize(80, 35));
        label_13->setAlignment(Qt::AlignCenter);

        verticalLayout_36->addWidget(label_13);


        horizontalLayout_14->addLayout(verticalLayout_36);

        verticalLayout_7 = new QVBoxLayout();
        verticalLayout_7->setObjectName(QString::fromUtf8("verticalLayout_7"));
        Food_Add_Name_plainTextEdit = new QPlainTextEdit(Food_Add);
        Food_Add_Name_plainTextEdit->setObjectName(QString::fromUtf8("Food_Add_Name_plainTextEdit"));
        Food_Add_Name_plainTextEdit->setMinimumSize(QSize(430, 30));
        Food_Add_Name_plainTextEdit->setMaximumSize(QSize(500, 35));
        Food_Add_Name_plainTextEdit->setFont(font1);

        verticalLayout_7->addWidget(Food_Add_Name_plainTextEdit);

        Food_Add_Type_plainTextEdit = new QPlainTextEdit(Food_Add);
        Food_Add_Type_plainTextEdit->setObjectName(QString::fromUtf8("Food_Add_Type_plainTextEdit"));
        Food_Add_Type_plainTextEdit->setMinimumSize(QSize(430, 30));
        Food_Add_Type_plainTextEdit->setMaximumSize(QSize(500, 35));
        Food_Add_Type_plainTextEdit->setFont(font1);

        verticalLayout_7->addWidget(Food_Add_Type_plainTextEdit);

        Food_Add_Num_spinBox = new QSpinBox(Food_Add);
        Food_Add_Num_spinBox->setObjectName(QString::fromUtf8("Food_Add_Num_spinBox"));
        Food_Add_Num_spinBox->setMinimumSize(QSize(430, 35));
        Food_Add_Num_spinBox->setMaximumSize(QSize(500, 40));
        Food_Add_Num_spinBox->setFont(font1);

        verticalLayout_7->addWidget(Food_Add_Num_spinBox);

        Food_Add_Date_plainTextEdit = new QPlainTextEdit(Food_Add);
        Food_Add_Date_plainTextEdit->setObjectName(QString::fromUtf8("Food_Add_Date_plainTextEdit"));
        Food_Add_Date_plainTextEdit->setMinimumSize(QSize(430, 30));
        Food_Add_Date_plainTextEdit->setMaximumSize(QSize(500, 35));
        Food_Add_Date_plainTextEdit->setFont(font1);
        Food_Add_Date_plainTextEdit->setInputMethodHints(Qt::ImhMultiLine);

        verticalLayout_7->addWidget(Food_Add_Date_plainTextEdit);

        Food_Add_DueDate_plainTextEdit = new QPlainTextEdit(Food_Add);
        Food_Add_DueDate_plainTextEdit->setObjectName(QString::fromUtf8("Food_Add_DueDate_plainTextEdit"));
        Food_Add_DueDate_plainTextEdit->setMinimumSize(QSize(430, 30));
        Food_Add_DueDate_plainTextEdit->setMaximumSize(QSize(500, 35));
        Food_Add_DueDate_plainTextEdit->setFont(font1);
        Food_Add_DueDate_plainTextEdit->setInputMethodHints(Qt::ImhMultiLine);

        verticalLayout_7->addWidget(Food_Add_DueDate_plainTextEdit);

        horizontalLayout_13 = new QHBoxLayout();
        horizontalLayout_13->setObjectName(QString::fromUtf8("horizontalLayout_13"));
        Food_Add_Picture_plainTextEdit = new QPlainTextEdit(Food_Add);
        Food_Add_Picture_plainTextEdit->setObjectName(QString::fromUtf8("Food_Add_Picture_plainTextEdit"));
        Food_Add_Picture_plainTextEdit->setMinimumSize(QSize(320, 30));
        Food_Add_Picture_plainTextEdit->setMaximumSize(QSize(335, 35));
        Food_Add_Picture_plainTextEdit->setFont(font1);

        horizontalLayout_13->addWidget(Food_Add_Picture_plainTextEdit);

        Food_Add_Picture_pushButton = new QPushButton(Food_Add);
        Food_Add_Picture_pushButton->setObjectName(QString::fromUtf8("Food_Add_Picture_pushButton"));
        Food_Add_Picture_pushButton->setMinimumSize(QSize(100, 30));
        Food_Add_Picture_pushButton->setMaximumSize(QSize(100, 35));

        horizontalLayout_13->addWidget(Food_Add_Picture_pushButton);


        verticalLayout_7->addLayout(horizontalLayout_13);


        horizontalLayout_14->addLayout(verticalLayout_7);


        verticalLayout_13->addLayout(horizontalLayout_14);

        verticalLayout_38 = new QVBoxLayout();
        verticalLayout_38->setObjectName(QString::fromUtf8("verticalLayout_38"));
        verticalLayout_38->setContentsMargins(-1, -1, -1, 15);
        horizontalLayout_36 = new QHBoxLayout();
        horizontalLayout_36->setObjectName(QString::fromUtf8("horizontalLayout_36"));
        label_39 = new QLabel(Food_Add);
        label_39->setObjectName(QString::fromUtf8("label_39"));
        label_39->setMinimumSize(QSize(0, 30));
        label_39->setMaximumSize(QSize(16777215, 35));
        label_39->setFont(font1);
        label_39->setAlignment(Qt::AlignCenter);

        horizontalLayout_36->addWidget(label_39);


        verticalLayout_38->addLayout(horizontalLayout_36);

        horizontalLayout_37 = new QHBoxLayout();
        horizontalLayout_37->setObjectName(QString::fromUtf8("horizontalLayout_37"));
        verticalLayout_39 = new QVBoxLayout();
        verticalLayout_39->setObjectName(QString::fromUtf8("verticalLayout_39"));
        label_40 = new QLabel(Food_Add);
        label_40->setObjectName(QString::fromUtf8("label_40"));
        label_40->setMinimumSize(QSize(80, 30));
        label_40->setMaximumSize(QSize(80, 35));
        label_40->setFont(font);
        label_40->setAlignment(Qt::AlignCenter);

        verticalLayout_39->addWidget(label_40);

        label_41 = new QLabel(Food_Add);
        label_41->setObjectName(QString::fromUtf8("label_41"));
        label_41->setMinimumSize(QSize(80, 30));
        label_41->setMaximumSize(QSize(80, 35));
        label_41->setFont(font);
        label_41->setAlignment(Qt::AlignCenter);

        verticalLayout_39->addWidget(label_41);


        horizontalLayout_37->addLayout(verticalLayout_39);

        verticalLayout_40 = new QVBoxLayout();
        verticalLayout_40->setObjectName(QString::fromUtf8("verticalLayout_40"));
        Food_Add_Storage_plainTextEdit = new QPlainTextEdit(Food_Add);
        Food_Add_Storage_plainTextEdit->setObjectName(QString::fromUtf8("Food_Add_Storage_plainTextEdit"));
        Food_Add_Storage_plainTextEdit->setMinimumSize(QSize(430, 30));
        Food_Add_Storage_plainTextEdit->setMaximumSize(QSize(500, 35));
        Food_Add_Storage_plainTextEdit->setFont(font1);

        verticalLayout_40->addWidget(Food_Add_Storage_plainTextEdit);

        Food_Add_Floor_plainTextEdit = new QPlainTextEdit(Food_Add);
        Food_Add_Floor_plainTextEdit->setObjectName(QString::fromUtf8("Food_Add_Floor_plainTextEdit"));
        Food_Add_Floor_plainTextEdit->setMinimumSize(QSize(430, 30));
        Food_Add_Floor_plainTextEdit->setMaximumSize(QSize(500, 35));
        Food_Add_Floor_plainTextEdit->setFont(font1);

        verticalLayout_40->addWidget(Food_Add_Floor_plainTextEdit);


        horizontalLayout_37->addLayout(verticalLayout_40);


        verticalLayout_38->addLayout(horizontalLayout_37);


        verticalLayout_13->addLayout(verticalLayout_38);

        horizontalLayout_38 = new QHBoxLayout();
        horizontalLayout_38->setObjectName(QString::fromUtf8("horizontalLayout_38"));
        horizontalSpacer_22 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_38->addItem(horizontalSpacer_22);

        Food_Add_pushButton = new QPushButton(Food_Add);
        Food_Add_pushButton->setObjectName(QString::fromUtf8("Food_Add_pushButton"));
        Food_Add_pushButton->setMinimumSize(QSize(100, 30));
        Food_Add_pushButton->setMaximumSize(QSize(150, 35));

        horizontalLayout_38->addWidget(Food_Add_pushButton);

        horizontalSpacer_23 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_38->addItem(horizontalSpacer_23);


        verticalLayout_13->addLayout(horizontalLayout_38);


        horizontalLayout_15->addLayout(verticalLayout_13);

        Item_tabWidget->addTab(Food_Add, QString());
        Item_Delete = new QWidget();
        Item_Delete->setObjectName(QString::fromUtf8("Item_Delete"));
        verticalLayout_42 = new QVBoxLayout(Item_Delete);
        verticalLayout_42->setObjectName(QString::fromUtf8("verticalLayout_42"));
        verticalLayout_41 = new QVBoxLayout();
        verticalLayout_41->setObjectName(QString::fromUtf8("verticalLayout_41"));
        horizontalLayout_35 = new QHBoxLayout();
        horizontalLayout_35->setObjectName(QString::fromUtf8("horizontalLayout_35"));
        horizontalLayout_35->setContentsMargins(-1, -1, -1, 30);
        label_43 = new QLabel(Item_Delete);
        label_43->setObjectName(QString::fromUtf8("label_43"));
        label_43->setMinimumSize(QSize(80, 35));
        label_43->setMaximumSize(QSize(80, 35));
        label_43->setFont(font);
        label_43->setAlignment(Qt::AlignCenter);

        horizontalLayout_35->addWidget(label_43);

        Item_Delete_plainTextEdit = new QPlainTextEdit(Item_Delete);
        Item_Delete_plainTextEdit->setObjectName(QString::fromUtf8("Item_Delete_plainTextEdit"));
        Item_Delete_plainTextEdit->setMinimumSize(QSize(430, 35));
        Item_Delete_plainTextEdit->setMaximumSize(QSize(500, 35));
        Item_Delete_plainTextEdit->setFont(font1);

        horizontalLayout_35->addWidget(Item_Delete_plainTextEdit);


        verticalLayout_41->addLayout(horizontalLayout_35);

        horizontalLayout_39 = new QHBoxLayout();
        horizontalLayout_39->setObjectName(QString::fromUtf8("horizontalLayout_39"));
        horizontalSpacer_24 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_39->addItem(horizontalSpacer_24);

        Item_Delete_pushButton = new QPushButton(Item_Delete);
        Item_Delete_pushButton->setObjectName(QString::fromUtf8("Item_Delete_pushButton"));
        Item_Delete_pushButton->setMinimumSize(QSize(100, 30));
        Item_Delete_pushButton->setMaximumSize(QSize(150, 35));

        horizontalLayout_39->addWidget(Item_Delete_pushButton);

        horizontalSpacer_25 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_39->addItem(horizontalSpacer_25);


        verticalLayout_41->addLayout(horizontalLayout_39);


        verticalLayout_42->addLayout(verticalLayout_41);

        label_44 = new QLabel(Item_Delete);
        label_44->setObjectName(QString::fromUtf8("label_44"));
        label_44->setMinimumSize(QSize(500, 50));
        label_44->setMaximumSize(QSize(500, 50));
        label_44->setFont(font);

        verticalLayout_42->addWidget(label_44);

        verticalSpacer_6 = new QSpacerItem(20, 163, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_42->addItem(verticalSpacer_6);

        Item_tabWidget->addTab(Item_Delete, QString());
        Item_Update = new QWidget();
        Item_Update->setObjectName(QString::fromUtf8("Item_Update"));
        horizontalLayout_29 = new QHBoxLayout(Item_Update);
        horizontalLayout_29->setObjectName(QString::fromUtf8("horizontalLayout_29"));
        verticalLayout_30 = new QVBoxLayout();
        verticalLayout_30->setObjectName(QString::fromUtf8("verticalLayout_30"));
        horizontalLayout_28 = new QHBoxLayout();
        horizontalLayout_28->setObjectName(QString::fromUtf8("horizontalLayout_28"));
        horizontalLayout_28->setContentsMargins(-1, -1, -1, 20);
        label_33 = new QLabel(Item_Update);
        label_33->setObjectName(QString::fromUtf8("label_33"));
        label_33->setMinimumSize(QSize(80, 35));
        label_33->setMaximumSize(QSize(80, 35));
        label_33->setFont(font);
        label_33->setAlignment(Qt::AlignCenter);

        horizontalLayout_28->addWidget(label_33);

        Item_Update_Label_plainTextEdit = new QPlainTextEdit(Item_Update);
        Item_Update_Label_plainTextEdit->setObjectName(QString::fromUtf8("Item_Update_Label_plainTextEdit"));
        Item_Update_Label_plainTextEdit->setMinimumSize(QSize(300, 35));
        Item_Update_Label_plainTextEdit->setMaximumSize(QSize(500, 35));
        Item_Update_Label_plainTextEdit->setFont(font1);

        horizontalLayout_28->addWidget(Item_Update_Label_plainTextEdit);

        Item_Update_Load_pushButton = new QPushButton(Item_Update);
        Item_Update_Load_pushButton->setObjectName(QString::fromUtf8("Item_Update_Load_pushButton"));
        Item_Update_Load_pushButton->setMinimumSize(QSize(100, 30));
        Item_Update_Load_pushButton->setMaximumSize(QSize(150, 35));

        horizontalLayout_28->addWidget(Item_Update_Load_pushButton);


        verticalLayout_30->addLayout(horizontalLayout_28);

        horizontalLayout_26 = new QHBoxLayout();
        horizontalLayout_26->setObjectName(QString::fromUtf8("horizontalLayout_26"));
        horizontalLayout_26->setContentsMargins(-1, -1, -1, 25);
        verticalLayout_31 = new QVBoxLayout();
        verticalLayout_31->setObjectName(QString::fromUtf8("verticalLayout_31"));
        label_27 = new QLabel(Item_Update);
        label_27->setObjectName(QString::fromUtf8("label_27"));
        label_27->setMinimumSize(QSize(80, 30));
        label_27->setMaximumSize(QSize(80, 35));
        label_27->setFont(font);
        label_27->setAlignment(Qt::AlignCenter);

        verticalLayout_31->addWidget(label_27);

        label_29 = new QLabel(Item_Update);
        label_29->setObjectName(QString::fromUtf8("label_29"));
        label_29->setMinimumSize(QSize(80, 30));
        label_29->setMaximumSize(QSize(80, 35));
        label_29->setFont(font);
        label_29->setAlignment(Qt::AlignCenter);

        verticalLayout_31->addWidget(label_29);

        label_30 = new QLabel(Item_Update);
        label_30->setObjectName(QString::fromUtf8("label_30"));
        label_30->setMinimumSize(QSize(80, 30));
        label_30->setMaximumSize(QSize(80, 35));
        label_30->setFont(font);
        label_30->setAlignment(Qt::AlignCenter);

        verticalLayout_31->addWidget(label_30);

        label_31 = new QLabel(Item_Update);
        label_31->setObjectName(QString::fromUtf8("label_31"));
        label_31->setMinimumSize(QSize(80, 30));
        label_31->setMaximumSize(QSize(80, 35));
        label_31->setFont(font);
        label_31->setAlignment(Qt::AlignCenter);

        verticalLayout_31->addWidget(label_31);

        label_32 = new QLabel(Item_Update);
        label_32->setObjectName(QString::fromUtf8("label_32"));
        label_32->setMinimumSize(QSize(80, 30));
        label_32->setMaximumSize(QSize(80, 35));
        label_32->setFont(font);
        label_32->setAlignment(Qt::AlignCenter);

        verticalLayout_31->addWidget(label_32);

        label_42 = new QLabel(Item_Update);
        label_42->setObjectName(QString::fromUtf8("label_42"));
        label_42->setMinimumSize(QSize(80, 30));
        label_42->setMaximumSize(QSize(80, 35));
        label_42->setFont(font);
        label_42->setAlignment(Qt::AlignCenter);

        verticalLayout_31->addWidget(label_42);

        label_14 = new QLabel(Item_Update);
        label_14->setObjectName(QString::fromUtf8("label_14"));
        label_14->setMinimumSize(QSize(80, 35));
        label_14->setMaximumSize(QSize(80, 35));
        label_14->setAlignment(Qt::AlignCenter);

        verticalLayout_31->addWidget(label_14);


        horizontalLayout_26->addLayout(verticalLayout_31);

        verticalLayout_32 = new QVBoxLayout();
        verticalLayout_32->setObjectName(QString::fromUtf8("verticalLayout_32"));
        Item_Update_Name_plainTextEdit = new QPlainTextEdit(Item_Update);
        Item_Update_Name_plainTextEdit->setObjectName(QString::fromUtf8("Item_Update_Name_plainTextEdit"));
        Item_Update_Name_plainTextEdit->setMinimumSize(QSize(430, 35));
        Item_Update_Name_plainTextEdit->setMaximumSize(QSize(500, 35));
        Item_Update_Name_plainTextEdit->setFont(font1);

        verticalLayout_32->addWidget(Item_Update_Name_plainTextEdit);

        Item_Update_Type_plainTextEdit = new QPlainTextEdit(Item_Update);
        Item_Update_Type_plainTextEdit->setObjectName(QString::fromUtf8("Item_Update_Type_plainTextEdit"));
        Item_Update_Type_plainTextEdit->setMinimumSize(QSize(430, 35));
        Item_Update_Type_plainTextEdit->setMaximumSize(QSize(500, 35));
        Item_Update_Type_plainTextEdit->setFont(font1);

        verticalLayout_32->addWidget(Item_Update_Type_plainTextEdit);

        Item_Update_Num_spinBox = new QSpinBox(Item_Update);
        Item_Update_Num_spinBox->setObjectName(QString::fromUtf8("Item_Update_Num_spinBox"));
        Item_Update_Num_spinBox->setMinimumSize(QSize(430, 35));
        Item_Update_Num_spinBox->setMaximumSize(QSize(500, 40));
        Item_Update_Num_spinBox->setFont(font1);

        verticalLayout_32->addWidget(Item_Update_Num_spinBox);

        Item_Update_Date_plainTextEdit = new QPlainTextEdit(Item_Update);
        Item_Update_Date_plainTextEdit->setObjectName(QString::fromUtf8("Item_Update_Date_plainTextEdit"));
        Item_Update_Date_plainTextEdit->setMinimumSize(QSize(430, 35));
        Item_Update_Date_plainTextEdit->setMaximumSize(QSize(500, 35));
        Item_Update_Date_plainTextEdit->setFont(font1);
        Item_Update_Date_plainTextEdit->setInputMethodHints(Qt::ImhMultiLine);

        verticalLayout_32->addWidget(Item_Update_Date_plainTextEdit);

        horizontalLayout_27 = new QHBoxLayout();
        horizontalLayout_27->setObjectName(QString::fromUtf8("horizontalLayout_27"));
        horizontalLayout_27->setSizeConstraint(QLayout::SetMinimumSize);
        Item_Update_Yes_radioButton = new QRadioButton(Item_Update);
        Item_Update_Yes_radioButton->setObjectName(QString::fromUtf8("Item_Update_Yes_radioButton"));
        Item_Update_Yes_radioButton->setMinimumSize(QSize(0, 35));
        Item_Update_Yes_radioButton->setMaximumSize(QSize(200, 35));
        Item_Update_Yes_radioButton->setFont(font);

        horizontalLayout_27->addWidget(Item_Update_Yes_radioButton);

        Item_Update_No_radioButton = new QRadioButton(Item_Update);
        Item_Update_No_radioButton->setObjectName(QString::fromUtf8("Item_Update_No_radioButton"));
        Item_Update_No_radioButton->setMinimumSize(QSize(0, 35));
        Item_Update_No_radioButton->setMaximumSize(QSize(200, 35));
        Item_Update_No_radioButton->setFont(font);

        horizontalLayout_27->addWidget(Item_Update_No_radioButton);


        verticalLayout_32->addLayout(horizontalLayout_27);

        Item_Update_DueDate_plainTextEdit = new QPlainTextEdit(Item_Update);
        Item_Update_DueDate_plainTextEdit->setObjectName(QString::fromUtf8("Item_Update_DueDate_plainTextEdit"));
        Item_Update_DueDate_plainTextEdit->setMinimumSize(QSize(430, 35));
        Item_Update_DueDate_plainTextEdit->setMaximumSize(QSize(500, 35));
        Item_Update_DueDate_plainTextEdit->setFont(font1);
        Item_Update_DueDate_plainTextEdit->setInputMethodHints(Qt::ImhMultiLine);

        verticalLayout_32->addWidget(Item_Update_DueDate_plainTextEdit);

        horizontalLayout_16 = new QHBoxLayout();
        horizontalLayout_16->setObjectName(QString::fromUtf8("horizontalLayout_16"));
        Item_Update_Picture_plainTextEdit = new QPlainTextEdit(Item_Update);
        Item_Update_Picture_plainTextEdit->setObjectName(QString::fromUtf8("Item_Update_Picture_plainTextEdit"));
        Item_Update_Picture_plainTextEdit->setMinimumSize(QSize(320, 35));
        Item_Update_Picture_plainTextEdit->setMaximumSize(QSize(330, 35));
        Item_Update_Picture_plainTextEdit->setFont(font1);

        horizontalLayout_16->addWidget(Item_Update_Picture_plainTextEdit);

        Item_Update_Picture_pushButton = new QPushButton(Item_Update);
        Item_Update_Picture_pushButton->setObjectName(QString::fromUtf8("Item_Update_Picture_pushButton"));
        Item_Update_Picture_pushButton->setMinimumSize(QSize(100, 35));
        Item_Update_Picture_pushButton->setMaximumSize(QSize(100, 35));

        horizontalLayout_16->addWidget(Item_Update_Picture_pushButton);


        verticalLayout_32->addLayout(horizontalLayout_16);


        horizontalLayout_26->addLayout(verticalLayout_32);


        verticalLayout_30->addLayout(horizontalLayout_26);

        verticalSpacer_8 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_30->addItem(verticalSpacer_8);

        horizontalLayout_30 = new QHBoxLayout();
        horizontalLayout_30->setObjectName(QString::fromUtf8("horizontalLayout_30"));
        horizontalSpacer_15 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_30->addItem(horizontalSpacer_15);

        Item_Update_pushButton = new QPushButton(Item_Update);
        Item_Update_pushButton->setObjectName(QString::fromUtf8("Item_Update_pushButton"));
        Item_Update_pushButton->setMinimumSize(QSize(100, 30));
        Item_Update_pushButton->setMaximumSize(QSize(150, 35));

        horizontalLayout_30->addWidget(Item_Update_pushButton);

        horizontalSpacer_16 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_30->addItem(horizontalSpacer_16);


        verticalLayout_30->addLayout(horizontalLayout_30);


        horizontalLayout_29->addLayout(verticalLayout_30);

        Item_tabWidget->addTab(Item_Update, QString());
        Storage_tabWidget = new QTabWidget(centralwidget);
        Storage_tabWidget->setObjectName(QString::fromUtf8("Storage_tabWidget"));
        Storage_tabWidget->setGeometry(QRect(30, 510, 555, 215));
        Storage_tabWidget->setFont(font);
        Storage_Add = new QWidget();
        Storage_Add->setObjectName(QString::fromUtf8("Storage_Add"));
        horizontalLayout_9 = new QHBoxLayout(Storage_Add);
        horizontalLayout_9->setObjectName(QString::fromUtf8("horizontalLayout_9"));
        verticalLayout_10 = new QVBoxLayout();
        verticalLayout_10->setObjectName(QString::fromUtf8("verticalLayout_10"));
        horizontalLayout_7 = new QHBoxLayout();
        horizontalLayout_7->setObjectName(QString::fromUtf8("horizontalLayout_7"));
        verticalLayout_8 = new QVBoxLayout();
        verticalLayout_8->setObjectName(QString::fromUtf8("verticalLayout_8"));
        label_15 = new QLabel(Storage_Add);
        label_15->setObjectName(QString::fromUtf8("label_15"));
        label_15->setMinimumSize(QSize(80, 30));
        label_15->setMaximumSize(QSize(80, 35));
        label_15->setFont(font);
        label_15->setAlignment(Qt::AlignCenter);

        verticalLayout_8->addWidget(label_15);

        label_10 = new QLabel(Storage_Add);
        label_10->setObjectName(QString::fromUtf8("label_10"));
        label_10->setMinimumSize(QSize(80, 30));
        label_10->setMaximumSize(QSize(80, 35));
        label_10->setFont(font);
        label_10->setAlignment(Qt::AlignCenter);

        verticalLayout_8->addWidget(label_10);

        label_11 = new QLabel(Storage_Add);
        label_11->setObjectName(QString::fromUtf8("label_11"));
        label_11->setMinimumSize(QSize(80, 30));
        label_11->setMaximumSize(QSize(80, 35));
        label_11->setFont(font);
        label_11->setAlignment(Qt::AlignCenter);

        verticalLayout_8->addWidget(label_11);


        horizontalLayout_7->addLayout(verticalLayout_8);

        verticalLayout_9 = new QVBoxLayout();
        verticalLayout_9->setObjectName(QString::fromUtf8("verticalLayout_9"));
        Storage_Add_Label_plainTextEdit = new QPlainTextEdit(Storage_Add);
        Storage_Add_Label_plainTextEdit->setObjectName(QString::fromUtf8("Storage_Add_Label_plainTextEdit"));
        Storage_Add_Label_plainTextEdit->setMinimumSize(QSize(430, 30));
        Storage_Add_Label_plainTextEdit->setMaximumSize(QSize(500, 35));
        Storage_Add_Label_plainTextEdit->setFont(font1);

        verticalLayout_9->addWidget(Storage_Add_Label_plainTextEdit);

        Storage_Add_Type_plainTextEdit = new QPlainTextEdit(Storage_Add);
        Storage_Add_Type_plainTextEdit->setObjectName(QString::fromUtf8("Storage_Add_Type_plainTextEdit"));
        Storage_Add_Type_plainTextEdit->setMinimumSize(QSize(430, 30));
        Storage_Add_Type_plainTextEdit->setMaximumSize(QSize(500, 35));
        Storage_Add_Type_plainTextEdit->setFont(font1);

        verticalLayout_9->addWidget(Storage_Add_Type_plainTextEdit);

        Storage_Add_Floor_plainTextEdit = new QPlainTextEdit(Storage_Add);
        Storage_Add_Floor_plainTextEdit->setObjectName(QString::fromUtf8("Storage_Add_Floor_plainTextEdit"));
        Storage_Add_Floor_plainTextEdit->setMinimumSize(QSize(430, 30));
        Storage_Add_Floor_plainTextEdit->setMaximumSize(QSize(500, 35));
        Storage_Add_Floor_plainTextEdit->setFont(font1);

        verticalLayout_9->addWidget(Storage_Add_Floor_plainTextEdit);


        horizontalLayout_7->addLayout(verticalLayout_9);


        verticalLayout_10->addLayout(horizontalLayout_7);

        horizontalLayout_8 = new QHBoxLayout();
        horizontalLayout_8->setObjectName(QString::fromUtf8("horizontalLayout_8"));
        horizontalSpacer_3 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_8->addItem(horizontalSpacer_3);

        Storage_Add_pushButton = new QPushButton(Storage_Add);
        Storage_Add_pushButton->setObjectName(QString::fromUtf8("Storage_Add_pushButton"));
        Storage_Add_pushButton->setMinimumSize(QSize(100, 30));
        Storage_Add_pushButton->setMaximumSize(QSize(150, 35));

        horizontalLayout_8->addWidget(Storage_Add_pushButton);

        horizontalSpacer_4 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_8->addItem(horizontalSpacer_4);


        verticalLayout_10->addLayout(horizontalLayout_8);


        horizontalLayout_9->addLayout(verticalLayout_10);

        Storage_tabWidget->addTab(Storage_Add, QString());
        Storage_Update = new QWidget();
        Storage_Update->setObjectName(QString::fromUtf8("Storage_Update"));
        horizontalLayout_18 = new QHBoxLayout(Storage_Update);
        horizontalLayout_18->setObjectName(QString::fromUtf8("horizontalLayout_18"));
        horizontalLayout_17 = new QHBoxLayout();
        horizontalLayout_17->setObjectName(QString::fromUtf8("horizontalLayout_17"));
        verticalLayout_18 = new QVBoxLayout();
        verticalLayout_18->setObjectName(QString::fromUtf8("verticalLayout_18"));
        label_17 = new QLabel(Storage_Update);
        label_17->setObjectName(QString::fromUtf8("label_17"));
        label_17->setMinimumSize(QSize(80, 30));
        label_17->setMaximumSize(QSize(80, 35));
        label_17->setFont(font);
        label_17->setAlignment(Qt::AlignCenter);

        verticalLayout_18->addWidget(label_17);

        label_19 = new QLabel(Storage_Update);
        label_19->setObjectName(QString::fromUtf8("label_19"));
        label_19->setMinimumSize(QSize(80, 30));
        label_19->setMaximumSize(QSize(80, 35));
        label_19->setFont(font);
        label_19->setAlignment(Qt::AlignCenter);

        verticalLayout_18->addWidget(label_19);

        label_20 = new QLabel(Storage_Update);
        label_20->setObjectName(QString::fromUtf8("label_20"));
        label_20->setMinimumSize(QSize(80, 30));
        label_20->setMaximumSize(QSize(80, 35));
        label_20->setFont(font);
        label_20->setAlignment(Qt::AlignCenter);

        verticalLayout_18->addWidget(label_20);


        horizontalLayout_17->addLayout(verticalLayout_18);

        verticalLayout_19 = new QVBoxLayout();
        verticalLayout_19->setObjectName(QString::fromUtf8("verticalLayout_19"));
        Storage_Update_Label_plainTextEdit = new QPlainTextEdit(Storage_Update);
        Storage_Update_Label_plainTextEdit->setObjectName(QString::fromUtf8("Storage_Update_Label_plainTextEdit"));
        Storage_Update_Label_plainTextEdit->setMinimumSize(QSize(300, 30));
        Storage_Update_Label_plainTextEdit->setMaximumSize(QSize(500, 35));
        Storage_Update_Label_plainTextEdit->setFont(font1);

        verticalLayout_19->addWidget(Storage_Update_Label_plainTextEdit);

        Storage_Update_Type_plainTextEdit = new QPlainTextEdit(Storage_Update);
        Storage_Update_Type_plainTextEdit->setObjectName(QString::fromUtf8("Storage_Update_Type_plainTextEdit"));
        Storage_Update_Type_plainTextEdit->setMinimumSize(QSize(300, 30));
        Storage_Update_Type_plainTextEdit->setMaximumSize(QSize(500, 35));
        Storage_Update_Type_plainTextEdit->setFont(font1);

        verticalLayout_19->addWidget(Storage_Update_Type_plainTextEdit);

        Storage_Update_Floor_textBrowser = new QTextBrowser(Storage_Update);
        Storage_Update_Floor_textBrowser->setObjectName(QString::fromUtf8("Storage_Update_Floor_textBrowser"));
        Storage_Update_Floor_textBrowser->setMinimumSize(QSize(300, 30));
        Storage_Update_Floor_textBrowser->setMaximumSize(QSize(500, 35));
        Storage_Update_Floor_textBrowser->setFont(font1);

        verticalLayout_19->addWidget(Storage_Update_Floor_textBrowser);


        horizontalLayout_17->addLayout(verticalLayout_19);

        verticalLayout_20 = new QVBoxLayout();
        verticalLayout_20->setObjectName(QString::fromUtf8("verticalLayout_20"));
        Storage_Update_Load_pushButton = new QPushButton(Storage_Update);
        Storage_Update_Load_pushButton->setObjectName(QString::fromUtf8("Storage_Update_Load_pushButton"));
        Storage_Update_Load_pushButton->setMinimumSize(QSize(100, 30));
        Storage_Update_Load_pushButton->setMaximumSize(QSize(150, 35));

        verticalLayout_20->addWidget(Storage_Update_Load_pushButton);

        verticalSpacer_3 = new QSpacerItem(20, 30, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_20->addItem(verticalSpacer_3);

        Storage_Update_pushButton = new QPushButton(Storage_Update);
        Storage_Update_pushButton->setObjectName(QString::fromUtf8("Storage_Update_pushButton"));
        Storage_Update_pushButton->setMinimumSize(QSize(100, 30));
        Storage_Update_pushButton->setMaximumSize(QSize(150, 35));

        verticalLayout_20->addWidget(Storage_Update_pushButton);


        horizontalLayout_17->addLayout(verticalLayout_20);


        horizontalLayout_18->addLayout(horizontalLayout_17);

        Storage_tabWidget->addTab(Storage_Update, QString());
        Storage_Delete = new QWidget();
        Storage_Delete->setObjectName(QString::fromUtf8("Storage_Delete"));
        verticalLayout_12 = new QVBoxLayout(Storage_Delete);
        verticalLayout_12->setObjectName(QString::fromUtf8("verticalLayout_12"));
        verticalLayout_11 = new QVBoxLayout();
        verticalLayout_11->setObjectName(QString::fromUtf8("verticalLayout_11"));
        horizontalLayout_10 = new QHBoxLayout();
        horizontalLayout_10->setObjectName(QString::fromUtf8("horizontalLayout_10"));
        horizontalLayout_10->setContentsMargins(-1, 15, -1, 15);
        label_12 = new QLabel(Storage_Delete);
        label_12->setObjectName(QString::fromUtf8("label_12"));
        label_12->setMinimumSize(QSize(80, 30));
        label_12->setMaximumSize(QSize(80, 35));
        label_12->setFont(font);
        label_12->setAlignment(Qt::AlignCenter);

        horizontalLayout_10->addWidget(label_12);

        Storage_Delete_Label_plainTextEdit = new QPlainTextEdit(Storage_Delete);
        Storage_Delete_Label_plainTextEdit->setObjectName(QString::fromUtf8("Storage_Delete_Label_plainTextEdit"));
        Storage_Delete_Label_plainTextEdit->setMinimumSize(QSize(430, 30));
        Storage_Delete_Label_plainTextEdit->setMaximumSize(QSize(500, 35));
        Storage_Delete_Label_plainTextEdit->setFont(font1);

        horizontalLayout_10->addWidget(Storage_Delete_Label_plainTextEdit);


        verticalLayout_11->addLayout(horizontalLayout_10);

        horizontalLayout_11 = new QHBoxLayout();
        horizontalLayout_11->setObjectName(QString::fromUtf8("horizontalLayout_11"));
        horizontalSpacer_5 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_11->addItem(horizontalSpacer_5);

        Storage_Delete_pushButton = new QPushButton(Storage_Delete);
        Storage_Delete_pushButton->setObjectName(QString::fromUtf8("Storage_Delete_pushButton"));
        Storage_Delete_pushButton->setMinimumSize(QSize(100, 30));
        Storage_Delete_pushButton->setMaximumSize(QSize(150, 35));

        horizontalLayout_11->addWidget(Storage_Delete_pushButton);

        horizontalSpacer_6 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_11->addItem(horizontalSpacer_6);


        verticalLayout_11->addLayout(horizontalLayout_11);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_11->addItem(verticalSpacer);


        verticalLayout_12->addLayout(verticalLayout_11);

        Storage_tabWidget->addTab(Storage_Delete, QString());
        Floor_Add = new QWidget();
        Floor_Add->setObjectName(QString::fromUtf8("Floor_Add"));
        horizontalLayout_21 = new QHBoxLayout(Floor_Add);
        horizontalLayout_21->setObjectName(QString::fromUtf8("horizontalLayout_21"));
        verticalLayout_23 = new QVBoxLayout();
        verticalLayout_23->setObjectName(QString::fromUtf8("verticalLayout_23"));
        horizontalLayout_20 = new QHBoxLayout();
        horizontalLayout_20->setObjectName(QString::fromUtf8("horizontalLayout_20"));
        horizontalLayout_20->setContentsMargins(-1, -1, -1, 30);
        verticalLayout_22 = new QVBoxLayout();
        verticalLayout_22->setObjectName(QString::fromUtf8("verticalLayout_22"));
        label_21 = new QLabel(Floor_Add);
        label_21->setObjectName(QString::fromUtf8("label_21"));
        label_21->setMinimumSize(QSize(110, 30));
        label_21->setMaximumSize(QSize(110, 35));
        label_21->setFont(font);
        label_21->setAlignment(Qt::AlignCenter);

        verticalLayout_22->addWidget(label_21);

        label_22 = new QLabel(Floor_Add);
        label_22->setObjectName(QString::fromUtf8("label_22"));
        label_22->setMinimumSize(QSize(110, 30));
        label_22->setMaximumSize(QSize(110, 35));
        label_22->setFont(font);
        label_22->setAlignment(Qt::AlignCenter);

        verticalLayout_22->addWidget(label_22);


        horizontalLayout_20->addLayout(verticalLayout_22);

        verticalLayout_21 = new QVBoxLayout();
        verticalLayout_21->setObjectName(QString::fromUtf8("verticalLayout_21"));
        Floor_Add_StorageLabel_plainTextEdit = new QPlainTextEdit(Floor_Add);
        Floor_Add_StorageLabel_plainTextEdit->setObjectName(QString::fromUtf8("Floor_Add_StorageLabel_plainTextEdit"));
        Floor_Add_StorageLabel_plainTextEdit->setMinimumSize(QSize(300, 30));
        Floor_Add_StorageLabel_plainTextEdit->setMaximumSize(QSize(500, 35));
        Floor_Add_StorageLabel_plainTextEdit->setFont(font1);

        verticalLayout_21->addWidget(Floor_Add_StorageLabel_plainTextEdit);

        Floor_Add_Type_plainTextEdit = new QPlainTextEdit(Floor_Add);
        Floor_Add_Type_plainTextEdit->setObjectName(QString::fromUtf8("Floor_Add_Type_plainTextEdit"));
        Floor_Add_Type_plainTextEdit->setMinimumSize(QSize(300, 30));
        Floor_Add_Type_plainTextEdit->setMaximumSize(QSize(500, 35));
        Floor_Add_Type_plainTextEdit->setFont(font1);

        verticalLayout_21->addWidget(Floor_Add_Type_plainTextEdit);


        horizontalLayout_20->addLayout(verticalLayout_21);


        verticalLayout_23->addLayout(horizontalLayout_20);

        horizontalLayout_19 = new QHBoxLayout();
        horizontalLayout_19->setObjectName(QString::fromUtf8("horizontalLayout_19"));
        horizontalSpacer_11 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_19->addItem(horizontalSpacer_11);

        Floor_Add_pushButton = new QPushButton(Floor_Add);
        Floor_Add_pushButton->setObjectName(QString::fromUtf8("Floor_Add_pushButton"));
        Floor_Add_pushButton->setMinimumSize(QSize(100, 30));
        Floor_Add_pushButton->setMaximumSize(QSize(150, 35));

        horizontalLayout_19->addWidget(Floor_Add_pushButton);

        horizontalSpacer_12 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_19->addItem(horizontalSpacer_12);


        verticalLayout_23->addLayout(horizontalLayout_19);


        horizontalLayout_21->addLayout(verticalLayout_23);

        Storage_tabWidget->addTab(Floor_Add, QString());
        Floor_Update = new QWidget();
        Floor_Update->setObjectName(QString::fromUtf8("Floor_Update"));
        horizontalLayout_33 = new QHBoxLayout(Floor_Update);
        horizontalLayout_33->setObjectName(QString::fromUtf8("horizontalLayout_33"));
        verticalLayout_34 = new QVBoxLayout();
        verticalLayout_34->setObjectName(QString::fromUtf8("verticalLayout_34"));
        horizontalLayout_24 = new QHBoxLayout();
        horizontalLayout_24->setObjectName(QString::fromUtf8("horizontalLayout_24"));
        verticalLayout_27 = new QVBoxLayout();
        verticalLayout_27->setObjectName(QString::fromUtf8("verticalLayout_27"));
        label_25 = new QLabel(Floor_Update);
        label_25->setObjectName(QString::fromUtf8("label_25"));
        label_25->setMinimumSize(QSize(110, 35));
        label_25->setMaximumSize(QSize(110, 35));
        label_25->setFont(font);
        label_25->setAlignment(Qt::AlignCenter);

        verticalLayout_27->addWidget(label_25);

        label_28 = new QLabel(Floor_Update);
        label_28->setObjectName(QString::fromUtf8("label_28"));
        label_28->setMinimumSize(QSize(80, 35));
        label_28->setMaximumSize(QSize(110, 35));
        label_28->setFont(font);
        label_28->setAlignment(Qt::AlignCenter);

        verticalLayout_27->addWidget(label_28);

        label_26 = new QLabel(Floor_Update);
        label_26->setObjectName(QString::fromUtf8("label_26"));
        label_26->setMinimumSize(QSize(80, 35));
        label_26->setMaximumSize(QSize(110, 35));
        label_26->setFont(font);
        label_26->setAlignment(Qt::AlignCenter);

        verticalLayout_27->addWidget(label_26);


        horizontalLayout_24->addLayout(verticalLayout_27);

        verticalLayout_28 = new QVBoxLayout();
        verticalLayout_28->setObjectName(QString::fromUtf8("verticalLayout_28"));
        Floor_Update_StorageLabel_plainTextEdit = new QPlainTextEdit(Floor_Update);
        Floor_Update_StorageLabel_plainTextEdit->setObjectName(QString::fromUtf8("Floor_Update_StorageLabel_plainTextEdit"));
        Floor_Update_StorageLabel_plainTextEdit->setMinimumSize(QSize(300, 35));
        Floor_Update_StorageLabel_plainTextEdit->setMaximumSize(QSize(500, 35));
        Floor_Update_StorageLabel_plainTextEdit->setFont(font1);

        verticalLayout_28->addWidget(Floor_Update_StorageLabel_plainTextEdit);

        Floor_Update_Floor_plainTextEdit = new QPlainTextEdit(Floor_Update);
        Floor_Update_Floor_plainTextEdit->setObjectName(QString::fromUtf8("Floor_Update_Floor_plainTextEdit"));
        Floor_Update_Floor_plainTextEdit->setMinimumSize(QSize(300, 35));
        Floor_Update_Floor_plainTextEdit->setMaximumSize(QSize(500, 35));
        Floor_Update_Floor_plainTextEdit->setFont(font1);

        verticalLayout_28->addWidget(Floor_Update_Floor_plainTextEdit);

        Floor_Update_Type_plainTextEdit = new QPlainTextEdit(Floor_Update);
        Floor_Update_Type_plainTextEdit->setObjectName(QString::fromUtf8("Floor_Update_Type_plainTextEdit"));
        Floor_Update_Type_plainTextEdit->setMinimumSize(QSize(300, 35));
        Floor_Update_Type_plainTextEdit->setMaximumSize(QSize(500, 35));
        Floor_Update_Type_plainTextEdit->setFont(font1);

        verticalLayout_28->addWidget(Floor_Update_Type_plainTextEdit);


        horizontalLayout_24->addLayout(verticalLayout_28);

        verticalLayout_29 = new QVBoxLayout();
        verticalLayout_29->setObjectName(QString::fromUtf8("verticalLayout_29"));
        verticalSpacer_5 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_29->addItem(verticalSpacer_5);

        Floor_Update_Load_pushButton = new QPushButton(Floor_Update);
        Floor_Update_Load_pushButton->setObjectName(QString::fromUtf8("Floor_Update_Load_pushButton"));
        Floor_Update_Load_pushButton->setMinimumSize(QSize(100, 30));
        Floor_Update_Load_pushButton->setMaximumSize(QSize(150, 35));

        verticalLayout_29->addWidget(Floor_Update_Load_pushButton);

        verticalSpacer_4 = new QSpacerItem(20, 30, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_29->addItem(verticalSpacer_4);


        horizontalLayout_24->addLayout(verticalLayout_29);


        verticalLayout_34->addLayout(horizontalLayout_24);

        horizontalLayout_32 = new QHBoxLayout();
        horizontalLayout_32->setObjectName(QString::fromUtf8("horizontalLayout_32"));
        horizontalSpacer_20 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_32->addItem(horizontalSpacer_20);

        Floor_Update_pushButton = new QPushButton(Floor_Update);
        Floor_Update_pushButton->setObjectName(QString::fromUtf8("Floor_Update_pushButton"));
        Floor_Update_pushButton->setMinimumSize(QSize(100, 30));
        Floor_Update_pushButton->setMaximumSize(QSize(150, 35));

        horizontalLayout_32->addWidget(Floor_Update_pushButton);

        horizontalSpacer_21 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_32->addItem(horizontalSpacer_21);


        verticalLayout_34->addLayout(horizontalLayout_32);


        horizontalLayout_33->addLayout(verticalLayout_34);

        Storage_tabWidget->addTab(Floor_Update, QString());
        Floor_Delete = new QWidget();
        Floor_Delete->setObjectName(QString::fromUtf8("Floor_Delete"));
        horizontalLayout_25 = new QHBoxLayout(Floor_Delete);
        horizontalLayout_25->setObjectName(QString::fromUtf8("horizontalLayout_25"));
        verticalLayout_24 = new QVBoxLayout();
        verticalLayout_24->setObjectName(QString::fromUtf8("verticalLayout_24"));
        horizontalLayout_22 = new QHBoxLayout();
        horizontalLayout_22->setObjectName(QString::fromUtf8("horizontalLayout_22"));
        horizontalLayout_22->setContentsMargins(-1, -1, -1, 30);
        verticalLayout_25 = new QVBoxLayout();
        verticalLayout_25->setObjectName(QString::fromUtf8("verticalLayout_25"));
        label_23 = new QLabel(Floor_Delete);
        label_23->setObjectName(QString::fromUtf8("label_23"));
        label_23->setMinimumSize(QSize(110, 30));
        label_23->setMaximumSize(QSize(110, 35));
        label_23->setFont(font);
        label_23->setAlignment(Qt::AlignCenter);

        verticalLayout_25->addWidget(label_23);

        label_24 = new QLabel(Floor_Delete);
        label_24->setObjectName(QString::fromUtf8("label_24"));
        label_24->setMinimumSize(QSize(110, 30));
        label_24->setMaximumSize(QSize(110, 35));
        label_24->setFont(font);
        label_24->setAlignment(Qt::AlignCenter);

        verticalLayout_25->addWidget(label_24);


        horizontalLayout_22->addLayout(verticalLayout_25);

        verticalLayout_26 = new QVBoxLayout();
        verticalLayout_26->setObjectName(QString::fromUtf8("verticalLayout_26"));
        Floor_Delete_StorageLabel_plainTextEdit = new QPlainTextEdit(Floor_Delete);
        Floor_Delete_StorageLabel_plainTextEdit->setObjectName(QString::fromUtf8("Floor_Delete_StorageLabel_plainTextEdit"));
        Floor_Delete_StorageLabel_plainTextEdit->setMinimumSize(QSize(300, 30));
        Floor_Delete_StorageLabel_plainTextEdit->setMaximumSize(QSize(500, 35));
        Floor_Delete_StorageLabel_plainTextEdit->setFont(font1);

        verticalLayout_26->addWidget(Floor_Delete_StorageLabel_plainTextEdit);

        Floor_Delete_Floor_plainTextEdit = new QPlainTextEdit(Floor_Delete);
        Floor_Delete_Floor_plainTextEdit->setObjectName(QString::fromUtf8("Floor_Delete_Floor_plainTextEdit"));
        Floor_Delete_Floor_plainTextEdit->setMinimumSize(QSize(300, 30));
        Floor_Delete_Floor_plainTextEdit->setMaximumSize(QSize(500, 35));
        Floor_Delete_Floor_plainTextEdit->setFont(font1);

        verticalLayout_26->addWidget(Floor_Delete_Floor_plainTextEdit);


        horizontalLayout_22->addLayout(verticalLayout_26);


        verticalLayout_24->addLayout(horizontalLayout_22);

        horizontalLayout_23 = new QHBoxLayout();
        horizontalLayout_23->setObjectName(QString::fromUtf8("horizontalLayout_23"));
        horizontalSpacer_13 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_23->addItem(horizontalSpacer_13);

        Floor_Delete_pushButton = new QPushButton(Floor_Delete);
        Floor_Delete_pushButton->setObjectName(QString::fromUtf8("Floor_Delete_pushButton"));
        Floor_Delete_pushButton->setMinimumSize(QSize(100, 30));
        Floor_Delete_pushButton->setMaximumSize(QSize(150, 35));

        horizontalLayout_23->addWidget(Floor_Delete_pushButton);

        horizontalSpacer_14 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_23->addItem(horizontalSpacer_14);


        verticalLayout_24->addLayout(horizontalLayout_23);


        horizontalLayout_25->addLayout(verticalLayout_24);

        Storage_tabWidget->addTab(Floor_Delete, QString());
        layoutWidget = new QWidget(centralwidget);
        layoutWidget->setObjectName(QString::fromUtf8("layoutWidget"));
        layoutWidget->setGeometry(QRect(620, 20, 451, 711));
        verticalLayout_33 = new QVBoxLayout(layoutWidget);
        verticalLayout_33->setObjectName(QString::fromUtf8("verticalLayout_33"));
        verticalLayout_33->setContentsMargins(0, 0, 0, 0);
        treeView = new QTreeView(layoutWidget);
        treeView->setObjectName(QString::fromUtf8("treeView"));
        treeView->setMinimumSize(QSize(440, 600));
        treeView->setMaximumSize(QSize(450, 650));
        treeView->setFont(font);

        verticalLayout_33->addWidget(treeView);

        horizontalLayout_31 = new QHBoxLayout();
        horizontalLayout_31->setObjectName(QString::fromUtf8("horizontalLayout_31"));
        horizontalLayout_31->setContentsMargins(-1, 10, -1, -1);
        horizontalSpacer_17 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_31->addItem(horizontalSpacer_17);

        Display_All_pushButton = new QPushButton(layoutWidget);
        Display_All_pushButton->setObjectName(QString::fromUtf8("Display_All_pushButton"));
        Display_All_pushButton->setMinimumSize(QSize(120, 30));
        Display_All_pushButton->setMaximumSize(QSize(150, 35));

        horizontalLayout_31->addWidget(Display_All_pushButton);

        horizontalSpacer_18 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_31->addItem(horizontalSpacer_18);

        Clear_pushButton = new QPushButton(layoutWidget);
        Clear_pushButton->setObjectName(QString::fromUtf8("Clear_pushButton"));
        Clear_pushButton->setMinimumSize(QSize(100, 30));
        Clear_pushButton->setMaximumSize(QSize(150, 35));

        horizontalLayout_31->addWidget(Clear_pushButton);

        horizontalSpacer_19 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_31->addItem(horizontalSpacer_19);


        verticalLayout_33->addLayout(horizontalLayout_31);

        Main_Info_label = new QLabel(centralwidget);
        Main_Info_label->setObjectName(QString::fromUtf8("Main_Info_label"));
        Main_Info_label->setGeometry(QRect(30, 730, 551, 31));
        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 1093, 32));
        menu_4 = new QMenu(menubar);
        menu_4->setObjectName(QString::fromUtf8("menu_4"));
        menuDisplay = new QMenu(menu_4);
        menuDisplay->setObjectName(QString::fromUtf8("menuDisplay"));
        menu_5 = new QMenu(menubar);
        menu_5->setObjectName(QString::fromUtf8("menu_5"));
        menuHelp = new QMenu(menubar);
        menuHelp->setObjectName(QString::fromUtf8("menuHelp"));
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        MainWindow->setStatusBar(statusbar);

        menubar->addAction(menu_4->menuAction());
        menubar->addAction(menu_5->menuAction());
        menubar->addAction(menuHelp->menuAction());
        menu_4->addAction(menuDisplay->menuAction());
        menu_4->addAction(actionSearch);
        menu_4->addAction(actionTemp_Dequeue);
        menuDisplay->addAction(actionHeirarchical);
        menuDisplay->addAction(actionRecent_List);
        menuDisplay->addAction(actionTemp_List);
        menu_5->addAction(actionItemSave);
        menu_5->addAction(actionLocationSave);
        menu_5->addSeparator();
        menu_5->addAction(actionItemLoad);
        menu_5->addAction(actionLocationLoad);
        menuHelp->addAction(actionManual);

        retranslateUi(MainWindow);

        Item_tabWidget->setCurrentIndex(3);
        Storage_tabWidget->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "DepotManagement", nullptr));
        actionItemSave->setText(QCoreApplication::translate("MainWindow", "\353\254\274\352\261\264 \354\240\225\353\263\264 \354\240\200\354\236\245", nullptr));
        actionLocationSave->setText(QCoreApplication::translate("MainWindow", "\354\236\245\354\206\214 \354\240\225\353\263\264 \354\240\200\354\236\245", nullptr));
        actionSearch->setText(QCoreApplication::translate("MainWindow", "\352\262\200\354\203\211", nullptr));
        actionRecent_List->setText(QCoreApplication::translate("MainWindow", "Recent List", nullptr));
        actionTemp_List->setText(QCoreApplication::translate("MainWindow", "Temp List", nullptr));
        actionHeirarchical->setText(QCoreApplication::translate("MainWindow", "Heirarchical", nullptr));
        actionTemp_Dequeue->setText(QCoreApplication::translate("MainWindow", "Load Temp Item", nullptr));
        actionItemLoad->setText(QCoreApplication::translate("MainWindow", "\353\254\274\352\261\264 \354\240\225\353\263\264 \353\266\210\353\237\254\354\230\244\352\270\260", nullptr));
        actionLocationLoad->setText(QCoreApplication::translate("MainWindow", "\354\236\245\354\206\214 \354\240\225\353\263\264 \353\266\210\353\237\254\354\230\244\352\270\260", nullptr));
        actionManual->setText(QCoreApplication::translate("MainWindow", "Manual", nullptr));
        label->setText(QCoreApplication::translate("MainWindow", "\354\235\264\353\246\204:", nullptr));
        label_2->setText(QCoreApplication::translate("MainWindow", "\354\242\205\353\245\230:", nullptr));
        label_3->setText(QCoreApplication::translate("MainWindow", "\352\260\234\354\210\230:", nullptr));
        label_4->setText(QCoreApplication::translate("MainWindow", "\352\265\254\354\236\205 \353\202\240\354\247\234:", nullptr));
        label_8->setText(QCoreApplication::translate("MainWindow", "\354\206\214\353\271\204\355\230\225:", nullptr));
        label_9->setText(QCoreApplication::translate("MainWindow", "\354\202\254\354\247\204 \352\262\275\353\241\234:", nullptr));
        Item_Add_type_plainTextEdit->setPlaceholderText(QString());
        Item_Add_Yes_radioButton->setText(QCoreApplication::translate("MainWindow", "\354\230\210", nullptr));
        Item_Add_No_radioButton->setText(QCoreApplication::translate("MainWindow", "\354\225\204\353\213\210\354\232\224", nullptr));
        Item_Add_Picture_plainTextEdit->setPlainText(QCoreApplication::translate("MainWindow", "None", nullptr));
        Item_Add_Picture_pushButton->setText(QCoreApplication::translate("MainWindow", "\354\202\254\354\247\204 \354\260\276\352\270\260", nullptr));
        label_5->setText(QCoreApplication::translate("MainWindow", "\353\263\264\352\264\200 \354\236\245\354\206\214", nullptr));
        label_6->setText(QCoreApplication::translate("MainWindow", "Storage:", nullptr));
        label_7->setText(QCoreApplication::translate("MainWindow", "Floor:", nullptr));
        Item_Add_pushButton->setText(QCoreApplication::translate("MainWindow", "\354\266\224\352\260\200", nullptr));
        Item_tabWidget->setTabText(Item_tabWidget->indexOf(Item_Add), QCoreApplication::translate("MainWindow", "\353\254\274\352\261\264 \354\266\224\352\260\200", nullptr));
        label_34->setText(QCoreApplication::translate("MainWindow", "\354\235\264\353\246\204:", nullptr));
        label_35->setText(QCoreApplication::translate("MainWindow", "\354\242\205\353\245\230:", nullptr));
        label_36->setText(QCoreApplication::translate("MainWindow", "\352\260\234\354\210\230:", nullptr));
        label_37->setText(QCoreApplication::translate("MainWindow", "\352\265\254\354\236\205 \353\202\240\354\247\234:", nullptr));
        label_38->setText(QCoreApplication::translate("MainWindow", "\354\234\240\355\206\265\352\270\260\355\225\234:", nullptr));
        label_13->setText(QCoreApplication::translate("MainWindow", "\354\202\254\354\247\204 \352\262\275\353\241\234:", nullptr));
        Food_Add_Type_plainTextEdit->setPlaceholderText(QString());
        Food_Add_Picture_plainTextEdit->setPlainText(QCoreApplication::translate("MainWindow", "None", nullptr));
        Food_Add_Picture_pushButton->setText(QCoreApplication::translate("MainWindow", "\354\202\254\354\247\204 \354\260\276\352\270\260", nullptr));
        label_39->setText(QCoreApplication::translate("MainWindow", "\353\263\264\352\264\200 \354\236\245\354\206\214", nullptr));
        label_40->setText(QCoreApplication::translate("MainWindow", "Storage:", nullptr));
        label_41->setText(QCoreApplication::translate("MainWindow", "Floor:", nullptr));
        Food_Add_pushButton->setText(QCoreApplication::translate("MainWindow", "\354\266\224\352\260\200", nullptr));
        Item_tabWidget->setTabText(Item_tabWidget->indexOf(Food_Add), QCoreApplication::translate("MainWindow", "\354\235\214\354\213\235 \354\266\224\352\260\200", nullptr));
        label_43->setText(QCoreApplication::translate("MainWindow", "Label:", nullptr));
        Item_Delete_pushButton->setText(QCoreApplication::translate("MainWindow", "\354\202\255\354\240\234", nullptr));
        label_44->setText(QString());
        Item_tabWidget->setTabText(Item_tabWidget->indexOf(Item_Delete), QCoreApplication::translate("MainWindow", "\354\202\255\354\240\234", nullptr));
        label_33->setText(QCoreApplication::translate("MainWindow", "Label:", nullptr));
        Item_Update_Load_pushButton->setText(QCoreApplication::translate("MainWindow", "\353\266\210\353\237\254\354\230\244\352\270\260", nullptr));
        label_27->setText(QCoreApplication::translate("MainWindow", "\354\235\264\353\246\204:", nullptr));
        label_29->setText(QCoreApplication::translate("MainWindow", "\354\242\205\353\245\230:", nullptr));
        label_30->setText(QCoreApplication::translate("MainWindow", "\352\260\234\354\210\230:", nullptr));
        label_31->setText(QCoreApplication::translate("MainWindow", "\352\265\254\354\236\205 \353\202\240\354\247\234:", nullptr));
        label_32->setText(QCoreApplication::translate("MainWindow", "\354\206\214\353\271\204\355\230\225:", nullptr));
        label_42->setText(QCoreApplication::translate("MainWindow", "\354\234\240\355\206\265\352\270\260\355\225\234:", nullptr));
        label_14->setText(QCoreApplication::translate("MainWindow", "\354\202\254\354\247\204 \352\262\275\353\241\234:", nullptr));
        Item_Update_Type_plainTextEdit->setPlaceholderText(QString());
        Item_Update_Yes_radioButton->setText(QCoreApplication::translate("MainWindow", "\354\230\210", nullptr));
        Item_Update_No_radioButton->setText(QCoreApplication::translate("MainWindow", "\354\225\204\353\213\210\354\232\224", nullptr));
        Item_Update_Picture_pushButton->setText(QCoreApplication::translate("MainWindow", "\354\202\254\354\247\204 \354\260\276\352\270\260", nullptr));
        Item_Update_pushButton->setText(QCoreApplication::translate("MainWindow", "\354\210\230\354\240\225", nullptr));
        Item_tabWidget->setTabText(Item_tabWidget->indexOf(Item_Update), QCoreApplication::translate("MainWindow", "\354\210\230\354\240\225", nullptr));
        label_15->setText(QCoreApplication::translate("MainWindow", "Label:", nullptr));
        label_10->setText(QCoreApplication::translate("MainWindow", "Type:", nullptr));
        label_11->setText(QCoreApplication::translate("MainWindow", "\354\270\265 \354\210\230:", nullptr));
        Storage_Add_pushButton->setText(QCoreApplication::translate("MainWindow", "\354\266\224\352\260\200", nullptr));
        Storage_tabWidget->setTabText(Storage_tabWidget->indexOf(Storage_Add), QCoreApplication::translate("MainWindow", "Storage \354\266\224\352\260\200", nullptr));
        label_17->setText(QCoreApplication::translate("MainWindow", "Label:", nullptr));
        label_19->setText(QCoreApplication::translate("MainWindow", "Type:", nullptr));
        label_20->setText(QCoreApplication::translate("MainWindow", "\354\270\265 \354\210\230:", nullptr));
        Storage_Update_Load_pushButton->setText(QCoreApplication::translate("MainWindow", "\353\266\210\353\237\254\354\230\244\352\270\260", nullptr));
        Storage_Update_pushButton->setText(QCoreApplication::translate("MainWindow", "\354\210\230\354\240\225", nullptr));
        Storage_tabWidget->setTabText(Storage_tabWidget->indexOf(Storage_Update), QCoreApplication::translate("MainWindow", "\354\210\230\354\240\225", nullptr));
        label_12->setText(QCoreApplication::translate("MainWindow", "Label:", nullptr));
        Storage_Delete_pushButton->setText(QCoreApplication::translate("MainWindow", "\354\202\255\354\240\234", nullptr));
        Storage_tabWidget->setTabText(Storage_tabWidget->indexOf(Storage_Delete), QCoreApplication::translate("MainWindow", "\354\202\255\354\240\234", nullptr));
        label_21->setText(QCoreApplication::translate("MainWindow", "Storage Label:", nullptr));
        label_22->setText(QCoreApplication::translate("MainWindow", "Floor Type:", nullptr));
        Floor_Add_pushButton->setText(QCoreApplication::translate("MainWindow", "\354\266\224\352\260\200", nullptr));
        Storage_tabWidget->setTabText(Storage_tabWidget->indexOf(Floor_Add), QCoreApplication::translate("MainWindow", "Floor \354\266\224\352\260\200", nullptr));
        label_25->setText(QCoreApplication::translate("MainWindow", "Storage Label:", nullptr));
        label_28->setText(QCoreApplication::translate("MainWindow", "\354\270\265 \354\210\230:", nullptr));
        label_26->setText(QCoreApplication::translate("MainWindow", "Type:", nullptr));
        Floor_Update_Load_pushButton->setText(QCoreApplication::translate("MainWindow", "\353\266\210\353\237\254\354\230\244\352\270\260", nullptr));
        Floor_Update_pushButton->setText(QCoreApplication::translate("MainWindow", "\354\210\230\354\240\225", nullptr));
        Storage_tabWidget->setTabText(Storage_tabWidget->indexOf(Floor_Update), QCoreApplication::translate("MainWindow", "\354\210\230\354\240\225", nullptr));
        label_23->setText(QCoreApplication::translate("MainWindow", "Storage Label:", nullptr));
        label_24->setText(QCoreApplication::translate("MainWindow", "Floor:", nullptr));
        Floor_Delete_pushButton->setText(QCoreApplication::translate("MainWindow", "\354\202\255\354\240\234", nullptr));
        Storage_tabWidget->setTabText(Storage_tabWidget->indexOf(Floor_Delete), QCoreApplication::translate("MainWindow", "\354\202\255\354\240\234", nullptr));
        Display_All_pushButton->setText(QCoreApplication::translate("MainWindow", "Display All Item", nullptr));
        Clear_pushButton->setText(QCoreApplication::translate("MainWindow", "Clear", nullptr));
        Main_Info_label->setText(QString());
        menu_4->setTitle(QCoreApplication::translate("MainWindow", "\352\270\260\353\212\245", nullptr));
        menuDisplay->setTitle(QCoreApplication::translate("MainWindow", "Display", nullptr));
        menu_5->setTitle(QCoreApplication::translate("MainWindow", "\354\240\200\354\236\245", nullptr));
        menuHelp->setTitle(QCoreApplication::translate("MainWindow", "Help", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
