/********************************************************************************
** Form generated from reading UI file 'picturewin.ui'
**
** Created by: Qt User Interface Compiler version 5.14.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_PICTUREWIN_H
#define UI_PICTUREWIN_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QVBoxLayout>

QT_BEGIN_NAMESPACE

class Ui_PictureWin
{
public:
    QHBoxLayout *horizontalLayout;
    QVBoxLayout *verticalLayout;
    QLabel *pic_label;
    QLabel *pic_path_label;

    void setupUi(QDialog *PictureWin)
    {
        if (PictureWin->objectName().isEmpty())
            PictureWin->setObjectName(QString::fromUtf8("PictureWin"));
        PictureWin->resize(530, 361);
        PictureWin->setStyleSheet(QString::fromUtf8("QDialog{\n"
"	background-image: url(:/images/images/LoadingBackground.png);\n"
"}"));
        horizontalLayout = new QHBoxLayout(PictureWin);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        pic_label = new QLabel(PictureWin);
        pic_label->setObjectName(QString::fromUtf8("pic_label"));
        pic_label->setMinimumSize(QSize(510, 310));

        verticalLayout->addWidget(pic_label);

        pic_path_label = new QLabel(PictureWin);
        pic_path_label->setObjectName(QString::fromUtf8("pic_path_label"));
        pic_path_label->setMinimumSize(QSize(0, 25));
        pic_path_label->setMaximumSize(QSize(600, 25));
        QFont font;
        font.setPointSize(10);
        pic_path_label->setFont(font);

        verticalLayout->addWidget(pic_path_label);


        horizontalLayout->addLayout(verticalLayout);


        retranslateUi(PictureWin);

        QMetaObject::connectSlotsByName(PictureWin);
    } // setupUi

    void retranslateUi(QDialog *PictureWin)
    {
        PictureWin->setWindowTitle(QCoreApplication::translate("PictureWin", "Dialog", nullptr));
        pic_label->setText(QString());
        pic_path_label->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class PictureWin: public Ui_PictureWin {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_PICTUREWIN_H
