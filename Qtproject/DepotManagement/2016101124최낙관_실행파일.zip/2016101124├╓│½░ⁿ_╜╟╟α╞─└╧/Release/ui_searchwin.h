/********************************************************************************
** Form generated from reading UI file 'searchwin.ui'
**
** Created by: Qt User Interface Compiler version 5.14.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SEARCHWIN_H
#define UI_SEARCHWIN_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPlainTextEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_SearchWin
{
public:
    QHBoxLayout *horizontalLayout_10;
    QTabWidget *tabWidget;
    QWidget *tab;
    QHBoxLayout *horizontalLayout_11;
    QVBoxLayout *verticalLayout_10;
    QHBoxLayout *horizontalLayout_3;
    QLabel *label_4;
    QHBoxLayout *horizontalLayout;
    QVBoxLayout *verticalLayout_3;
    QLabel *label;
    QLabel *label_2;
    QLabel *label_14;
    QVBoxLayout *verticalLayout;
    QPlainTextEdit *Object_Label_plainTextEdit;
    QPlainTextEdit *Object_Name_plainTextEdit;
    QPlainTextEdit *Object_Type_plainTextEdit;
    QVBoxLayout *verticalLayout_2;
    QPushButton *Object_Label_pushButton;
    QPushButton *Object_Name_pushButton;
    QPushButton *Object_Type_pushButton;
    QVBoxLayout *verticalLayout_16;
    QLabel *label_3;
    QHBoxLayout *horizontalLayout_6;
    QVBoxLayout *verticalLayout_18;
    QLabel *label_12;
    QLabel *label_13;
    QVBoxLayout *verticalLayout_9;
    QPlainTextEdit *Object_Date_From_plainText;
    QPlainTextEdit *Object_Date_To_plainText;
    QVBoxLayout *verticalLayout_4;
    QSpacerItem *verticalSpacer_5;
    QPushButton *Object_Date_pushButton;
    QHBoxLayout *horizontalLayout_7;
    QLabel *label_11;
    QPlainTextEdit *Object_DueDate_plainTextEdit;
    QPushButton *Object_DueDate_pushButton;
    QWidget *tab_2;
    QHBoxLayout *horizontalLayout_8;
    QVBoxLayout *verticalLayout_8;
    QLabel *label_7;
    QSpacerItem *verticalSpacer_3;
    QHBoxLayout *horizontalLayout_4;
    QVBoxLayout *verticalLayout_6;
    QLabel *label_5;
    QLabel *label_6;
    QVBoxLayout *verticalLayout_5;
    QPlainTextEdit *Storage_plainTextEdit;
    QPlainTextEdit *Floor_plainTextEdit;
    QVBoxLayout *verticalLayout_7;
    QPushButton *Storage_pushButton;
    QSpacerItem *horizontalSpacer;
    QHBoxLayout *horizontalLayout_5;
    QSpacerItem *horizontalSpacer_2;
    QPushButton *Floor_pushButton;
    QSpacerItem *horizontalSpacer_3;
    QSpacerItem *verticalSpacer_2;
    QWidget *tab_3;
    QHBoxLayout *horizontalLayout_9;
    QVBoxLayout *verticalLayout_15;
    QVBoxLayout *verticalLayout_14;
    QLabel *label_10;
    QHBoxLayout *horizontalLayout_2;
    QVBoxLayout *verticalLayout_11;
    QLabel *label_8;
    QLabel *label_9;
    QVBoxLayout *verticalLayout_12;
    QPlainTextEdit *Picture_Path_plainTextEdit;
    QPlainTextEdit *Picture_Label_plainTextEdit;
    QVBoxLayout *verticalLayout_13;
    QPushButton *Picture_Path_pushButton;
    QPushButton *Picture_Label_pushButton;
    QSpacerItem *verticalSpacer_4;

    void setupUi(QDialog *SearchWin)
    {
        if (SearchWin->objectName().isEmpty())
            SearchWin->setObjectName(QString::fromUtf8("SearchWin"));
        SearchWin->resize(540, 420);
        SearchWin->setStyleSheet(QString::fromUtf8("QDialog{\n"
"	\n"
"	background-image: url(:/images/images/SearchBackground.png);\n"
"}\n"
"QPushButton{\n"
"	background-color: rgba(120, 160, 255, 180);\n"
"	border-style: hidden;\n"
"	border-radius: 2px 7px;\n"
"	border-width: 1px\n"
"}\n"
"QPushButton:pressed{\n"
"	background-color: rgba(100, 120, 255, 180);\n"
"}\n"
"QTabBar::tab{\n"
"	background-color: rgba(120, 160, 255, 180);\n"
"	border-top-left-radius: 5px;\n"
"	border-top-right-radius: 5px;\n"
"	background-color: rgba(120, 160, 255, 180);\n"
"	border-style: solid;\n"
"	border-width: 1px;\n"
"	padding-top: 5px;\n"
"	padding-bottom: 5px;\n"
"	padding-left: 15px;\n"
"	padding-right: 15px;\n"
"}\n"
"QTabBar::tab:selected{\n"
"	/*background-color: rgba(190, 220, 255, 200);*/\n"
"	background-color: rgba(160, 200, 255, 180);\n"
"	border-radius: 5px;\n"
"	padding: 5px;\n"
"	margin-bottom: -1px;\n"
"	border-style: solid;\n"
"	border-top-color: rgba(255, 255, 255, 150);\n"
"	border-left-color: rgba(255, 255, 255, 150);\n"
"	border-right-color: rgba(255, 255, 25"
                        "5, 150);\n"
"	border-bottom-color: rgba(255, 255, 255, 150);\n"
"	padding-top: 5px;\n"
"	padding-bottom: 5px;\n"
"	padding-left: 15px;\n"
"	padding-right: 15px;\n"
"}\n"
"QTabWidget::pane{\n"
"	/*background-color: rgba(190, 220, 255, 200);*/\n"
"	background-color: rgba(160, 200, 255, 180);\n"
"	border-bottom-left-radius: 5px;\n"
"	border-bottom-right-radius: 5px;\n"
"	border-top-right-radius: 5px;\n"
"	border-style: solid;\n"
"	border-width: 1px;\n"
"	border-color: rgba(255, 255, 255, 150);\n"
"	padding: 5px;\n"
"	margin-top: -1px;	\n"
"}\n"
"QPlainTextEdit:focus{\n"
"	border-radius: 20px;\n"
"	border-style: solid;\n"
"	border-color:white;\n"
"}\n"
"QPlainTextEdit{\n"
"	border-radius: 20px;\n"
"	border-style: solid;\n"
"	border-color:white;\n"
"}"));
        horizontalLayout_10 = new QHBoxLayout(SearchWin);
        horizontalLayout_10->setObjectName(QString::fromUtf8("horizontalLayout_10"));
        tabWidget = new QTabWidget(SearchWin);
        tabWidget->setObjectName(QString::fromUtf8("tabWidget"));
        QFont font;
        font.setPointSize(10);
        tabWidget->setFont(font);
        tab = new QWidget();
        tab->setObjectName(QString::fromUtf8("tab"));
        horizontalLayout_11 = new QHBoxLayout(tab);
        horizontalLayout_11->setObjectName(QString::fromUtf8("horizontalLayout_11"));
        verticalLayout_10 = new QVBoxLayout();
        verticalLayout_10->setObjectName(QString::fromUtf8("verticalLayout_10"));
        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        label_4 = new QLabel(tab);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        QFont font1;
        font1.setPointSize(12);
        label_4->setFont(font1);
        label_4->setAlignment(Qt::AlignCenter);

        horizontalLayout_3->addWidget(label_4);


        verticalLayout_10->addLayout(horizontalLayout_3);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        verticalLayout_3 = new QVBoxLayout();
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        label = new QLabel(tab);
        label->setObjectName(QString::fromUtf8("label"));
        label->setMinimumSize(QSize(80, 0));
        label->setMaximumSize(QSize(100, 16777215));
        label->setFont(font);
        label->setAlignment(Qt::AlignCenter);

        verticalLayout_3->addWidget(label);

        label_2 = new QLabel(tab);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setMinimumSize(QSize(80, 0));
        label_2->setMaximumSize(QSize(100, 16777215));
        label_2->setFont(font);
        label_2->setAlignment(Qt::AlignCenter);

        verticalLayout_3->addWidget(label_2);

        label_14 = new QLabel(tab);
        label_14->setObjectName(QString::fromUtf8("label_14"));
        label_14->setMinimumSize(QSize(80, 0));
        label_14->setMaximumSize(QSize(100, 16777215));
        label_14->setAlignment(Qt::AlignCenter);

        verticalLayout_3->addWidget(label_14);


        horizontalLayout->addLayout(verticalLayout_3);

        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        Object_Label_plainTextEdit = new QPlainTextEdit(tab);
        Object_Label_plainTextEdit->setObjectName(QString::fromUtf8("Object_Label_plainTextEdit"));
        Object_Label_plainTextEdit->setMinimumSize(QSize(285, 30));
        Object_Label_plainTextEdit->setMaximumSize(QSize(285, 40));
        QFont font2;
        font2.setPointSize(11);
        Object_Label_plainTextEdit->setFont(font2);
        Object_Label_plainTextEdit->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);

        verticalLayout->addWidget(Object_Label_plainTextEdit);

        Object_Name_plainTextEdit = new QPlainTextEdit(tab);
        Object_Name_plainTextEdit->setObjectName(QString::fromUtf8("Object_Name_plainTextEdit"));
        Object_Name_plainTextEdit->setMinimumSize(QSize(285, 30));
        Object_Name_plainTextEdit->setMaximumSize(QSize(285, 40));
        Object_Name_plainTextEdit->setFont(font2);
        Object_Name_plainTextEdit->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);

        verticalLayout->addWidget(Object_Name_plainTextEdit);

        Object_Type_plainTextEdit = new QPlainTextEdit(tab);
        Object_Type_plainTextEdit->setObjectName(QString::fromUtf8("Object_Type_plainTextEdit"));
        Object_Type_plainTextEdit->setMinimumSize(QSize(285, 30));
        Object_Type_plainTextEdit->setMaximumSize(QSize(285, 40));
        Object_Type_plainTextEdit->setFont(font2);

        verticalLayout->addWidget(Object_Type_plainTextEdit);


        horizontalLayout->addLayout(verticalLayout);

        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        Object_Label_pushButton = new QPushButton(tab);
        Object_Label_pushButton->setObjectName(QString::fromUtf8("Object_Label_pushButton"));
        Object_Label_pushButton->setMinimumSize(QSize(100, 30));
        Object_Label_pushButton->setMaximumSize(QSize(150, 40));

        verticalLayout_2->addWidget(Object_Label_pushButton);

        Object_Name_pushButton = new QPushButton(tab);
        Object_Name_pushButton->setObjectName(QString::fromUtf8("Object_Name_pushButton"));
        Object_Name_pushButton->setMinimumSize(QSize(100, 30));
        Object_Name_pushButton->setMaximumSize(QSize(150, 40));

        verticalLayout_2->addWidget(Object_Name_pushButton);

        Object_Type_pushButton = new QPushButton(tab);
        Object_Type_pushButton->setObjectName(QString::fromUtf8("Object_Type_pushButton"));
        Object_Type_pushButton->setMinimumSize(QSize(100, 30));
        Object_Type_pushButton->setMaximumSize(QSize(150, 40));

        verticalLayout_2->addWidget(Object_Type_pushButton);


        horizontalLayout->addLayout(verticalLayout_2);


        verticalLayout_10->addLayout(horizontalLayout);

        verticalLayout_16 = new QVBoxLayout();
        verticalLayout_16->setObjectName(QString::fromUtf8("verticalLayout_16"));
        label_3 = new QLabel(tab);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setFont(font);
        label_3->setAlignment(Qt::AlignCenter);

        verticalLayout_16->addWidget(label_3);

        horizontalLayout_6 = new QHBoxLayout();
        horizontalLayout_6->setObjectName(QString::fromUtf8("horizontalLayout_6"));
        verticalLayout_18 = new QVBoxLayout();
        verticalLayout_18->setObjectName(QString::fromUtf8("verticalLayout_18"));
        label_12 = new QLabel(tab);
        label_12->setObjectName(QString::fromUtf8("label_12"));
        label_12->setMinimumSize(QSize(80, 0));
        label_12->setMaximumSize(QSize(100, 16777215));
        label_12->setFont(font);
        label_12->setAlignment(Qt::AlignCenter);

        verticalLayout_18->addWidget(label_12);

        label_13 = new QLabel(tab);
        label_13->setObjectName(QString::fromUtf8("label_13"));
        label_13->setMinimumSize(QSize(80, 0));
        label_13->setMaximumSize(QSize(100, 16777215));
        label_13->setFont(font);
        label_13->setAlignment(Qt::AlignCenter);

        verticalLayout_18->addWidget(label_13);


        horizontalLayout_6->addLayout(verticalLayout_18);

        verticalLayout_9 = new QVBoxLayout();
        verticalLayout_9->setObjectName(QString::fromUtf8("verticalLayout_9"));
        Object_Date_From_plainText = new QPlainTextEdit(tab);
        Object_Date_From_plainText->setObjectName(QString::fromUtf8("Object_Date_From_plainText"));
        Object_Date_From_plainText->setMinimumSize(QSize(285, 30));
        Object_Date_From_plainText->setMaximumSize(QSize(285, 40));
        Object_Date_From_plainText->setFont(font2);
        Object_Date_From_plainText->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);

        verticalLayout_9->addWidget(Object_Date_From_plainText);

        Object_Date_To_plainText = new QPlainTextEdit(tab);
        Object_Date_To_plainText->setObjectName(QString::fromUtf8("Object_Date_To_plainText"));
        Object_Date_To_plainText->setMinimumSize(QSize(285, 30));
        Object_Date_To_plainText->setMaximumSize(QSize(285, 40));
        Object_Date_To_plainText->setFont(font2);
        Object_Date_To_plainText->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);

        verticalLayout_9->addWidget(Object_Date_To_plainText);


        horizontalLayout_6->addLayout(verticalLayout_9);

        verticalLayout_4 = new QVBoxLayout();
        verticalLayout_4->setObjectName(QString::fromUtf8("verticalLayout_4"));
        verticalSpacer_5 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_4->addItem(verticalSpacer_5);

        Object_Date_pushButton = new QPushButton(tab);
        Object_Date_pushButton->setObjectName(QString::fromUtf8("Object_Date_pushButton"));
        Object_Date_pushButton->setMinimumSize(QSize(100, 40));
        Object_Date_pushButton->setMaximumSize(QSize(150, 40));

        verticalLayout_4->addWidget(Object_Date_pushButton);


        horizontalLayout_6->addLayout(verticalLayout_4);


        verticalLayout_16->addLayout(horizontalLayout_6);


        verticalLayout_10->addLayout(verticalLayout_16);

        horizontalLayout_7 = new QHBoxLayout();
        horizontalLayout_7->setObjectName(QString::fromUtf8("horizontalLayout_7"));
        label_11 = new QLabel(tab);
        label_11->setObjectName(QString::fromUtf8("label_11"));
        label_11->setMinimumSize(QSize(80, 0));
        label_11->setMaximumSize(QSize(80, 16777215));
        label_11->setFont(font);
        label_11->setAlignment(Qt::AlignCenter);

        horizontalLayout_7->addWidget(label_11);

        Object_DueDate_plainTextEdit = new QPlainTextEdit(tab);
        Object_DueDate_plainTextEdit->setObjectName(QString::fromUtf8("Object_DueDate_plainTextEdit"));
        Object_DueDate_plainTextEdit->setMinimumSize(QSize(285, 30));
        Object_DueDate_plainTextEdit->setMaximumSize(QSize(285, 40));
        Object_DueDate_plainTextEdit->setFont(font2);
        Object_DueDate_plainTextEdit->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);

        horizontalLayout_7->addWidget(Object_DueDate_plainTextEdit);

        Object_DueDate_pushButton = new QPushButton(tab);
        Object_DueDate_pushButton->setObjectName(QString::fromUtf8("Object_DueDate_pushButton"));
        Object_DueDate_pushButton->setMinimumSize(QSize(100, 30));
        Object_DueDate_pushButton->setMaximumSize(QSize(100, 40));

        horizontalLayout_7->addWidget(Object_DueDate_pushButton);


        verticalLayout_10->addLayout(horizontalLayout_7);


        horizontalLayout_11->addLayout(verticalLayout_10);

        tabWidget->addTab(tab, QString());
        tab_2 = new QWidget();
        tab_2->setObjectName(QString::fromUtf8("tab_2"));
        horizontalLayout_8 = new QHBoxLayout(tab_2);
        horizontalLayout_8->setObjectName(QString::fromUtf8("horizontalLayout_8"));
        verticalLayout_8 = new QVBoxLayout();
        verticalLayout_8->setObjectName(QString::fromUtf8("verticalLayout_8"));
        label_7 = new QLabel(tab_2);
        label_7->setObjectName(QString::fromUtf8("label_7"));
        label_7->setFont(font1);
        label_7->setAlignment(Qt::AlignCenter);

        verticalLayout_8->addWidget(label_7);

        verticalSpacer_3 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Fixed);

        verticalLayout_8->addItem(verticalSpacer_3);

        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
        verticalLayout_6 = new QVBoxLayout();
        verticalLayout_6->setObjectName(QString::fromUtf8("verticalLayout_6"));
        label_5 = new QLabel(tab_2);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setFont(font);
        label_5->setAlignment(Qt::AlignCenter);

        verticalLayout_6->addWidget(label_5);

        label_6 = new QLabel(tab_2);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setFont(font);
        label_6->setAlignment(Qt::AlignCenter);

        verticalLayout_6->addWidget(label_6);


        horizontalLayout_4->addLayout(verticalLayout_6);

        verticalLayout_5 = new QVBoxLayout();
        verticalLayout_5->setObjectName(QString::fromUtf8("verticalLayout_5"));
        Storage_plainTextEdit = new QPlainTextEdit(tab_2);
        Storage_plainTextEdit->setObjectName(QString::fromUtf8("Storage_plainTextEdit"));
        Storage_plainTextEdit->setMinimumSize(QSize(0, 30));
        Storage_plainTextEdit->setMaximumSize(QSize(16777215, 40));
        Storage_plainTextEdit->setFont(font2);
        Storage_plainTextEdit->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);

        verticalLayout_5->addWidget(Storage_plainTextEdit);

        Floor_plainTextEdit = new QPlainTextEdit(tab_2);
        Floor_plainTextEdit->setObjectName(QString::fromUtf8("Floor_plainTextEdit"));
        Floor_plainTextEdit->setMinimumSize(QSize(0, 30));
        Floor_plainTextEdit->setMaximumSize(QSize(16777215, 40));
        Floor_plainTextEdit->setFont(font2);
        Floor_plainTextEdit->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);

        verticalLayout_5->addWidget(Floor_plainTextEdit);


        horizontalLayout_4->addLayout(verticalLayout_5);

        verticalLayout_7 = new QVBoxLayout();
        verticalLayout_7->setObjectName(QString::fromUtf8("verticalLayout_7"));
        Storage_pushButton = new QPushButton(tab_2);
        Storage_pushButton->setObjectName(QString::fromUtf8("Storage_pushButton"));
        Storage_pushButton->setMinimumSize(QSize(100, 30));
        Storage_pushButton->setMaximumSize(QSize(150, 35));

        verticalLayout_7->addWidget(Storage_pushButton);

        horizontalSpacer = new QSpacerItem(40, 40, QSizePolicy::Expanding, QSizePolicy::Minimum);

        verticalLayout_7->addItem(horizontalSpacer);


        horizontalLayout_4->addLayout(verticalLayout_7);


        verticalLayout_8->addLayout(horizontalLayout_4);

        horizontalLayout_5 = new QHBoxLayout();
        horizontalLayout_5->setObjectName(QString::fromUtf8("horizontalLayout_5"));
        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_5->addItem(horizontalSpacer_2);

        Floor_pushButton = new QPushButton(tab_2);
        Floor_pushButton->setObjectName(QString::fromUtf8("Floor_pushButton"));
        Floor_pushButton->setMinimumSize(QSize(100, 30));
        Floor_pushButton->setMaximumSize(QSize(150, 40));

        horizontalLayout_5->addWidget(Floor_pushButton);

        horizontalSpacer_3 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_5->addItem(horizontalSpacer_3);


        verticalLayout_8->addLayout(horizontalLayout_5);

        verticalSpacer_2 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_8->addItem(verticalSpacer_2);


        horizontalLayout_8->addLayout(verticalLayout_8);

        tabWidget->addTab(tab_2, QString());
        tab_3 = new QWidget();
        tab_3->setObjectName(QString::fromUtf8("tab_3"));
        horizontalLayout_9 = new QHBoxLayout(tab_3);
        horizontalLayout_9->setObjectName(QString::fromUtf8("horizontalLayout_9"));
        verticalLayout_15 = new QVBoxLayout();
        verticalLayout_15->setObjectName(QString::fromUtf8("verticalLayout_15"));
        verticalLayout_14 = new QVBoxLayout();
        verticalLayout_14->setObjectName(QString::fromUtf8("verticalLayout_14"));
        label_10 = new QLabel(tab_3);
        label_10->setObjectName(QString::fromUtf8("label_10"));
        label_10->setFont(font1);
        label_10->setAlignment(Qt::AlignCenter);

        verticalLayout_14->addWidget(label_10);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        verticalLayout_11 = new QVBoxLayout();
        verticalLayout_11->setObjectName(QString::fromUtf8("verticalLayout_11"));
        label_8 = new QLabel(tab_3);
        label_8->setObjectName(QString::fromUtf8("label_8"));
        label_8->setFont(font);
        label_8->setAlignment(Qt::AlignCenter);

        verticalLayout_11->addWidget(label_8);

        label_9 = new QLabel(tab_3);
        label_9->setObjectName(QString::fromUtf8("label_9"));
        label_9->setFont(font);
        label_9->setAlignment(Qt::AlignCenter);

        verticalLayout_11->addWidget(label_9);


        horizontalLayout_2->addLayout(verticalLayout_11);

        verticalLayout_12 = new QVBoxLayout();
        verticalLayout_12->setObjectName(QString::fromUtf8("verticalLayout_12"));
        Picture_Path_plainTextEdit = new QPlainTextEdit(tab_3);
        Picture_Path_plainTextEdit->setObjectName(QString::fromUtf8("Picture_Path_plainTextEdit"));
        Picture_Path_plainTextEdit->setMinimumSize(QSize(0, 30));
        Picture_Path_plainTextEdit->setMaximumSize(QSize(16777215, 40));
        Picture_Path_plainTextEdit->setFont(font2);
        Picture_Path_plainTextEdit->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);

        verticalLayout_12->addWidget(Picture_Path_plainTextEdit);

        Picture_Label_plainTextEdit = new QPlainTextEdit(tab_3);
        Picture_Label_plainTextEdit->setObjectName(QString::fromUtf8("Picture_Label_plainTextEdit"));
        Picture_Label_plainTextEdit->setMinimumSize(QSize(0, 30));
        Picture_Label_plainTextEdit->setMaximumSize(QSize(16777215, 40));
        Picture_Label_plainTextEdit->setFont(font2);
        Picture_Label_plainTextEdit->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);

        verticalLayout_12->addWidget(Picture_Label_plainTextEdit);


        horizontalLayout_2->addLayout(verticalLayout_12);

        verticalLayout_13 = new QVBoxLayout();
        verticalLayout_13->setObjectName(QString::fromUtf8("verticalLayout_13"));
        Picture_Path_pushButton = new QPushButton(tab_3);
        Picture_Path_pushButton->setObjectName(QString::fromUtf8("Picture_Path_pushButton"));
        Picture_Path_pushButton->setMinimumSize(QSize(100, 30));
        Picture_Path_pushButton->setMaximumSize(QSize(150, 35));

        verticalLayout_13->addWidget(Picture_Path_pushButton);

        Picture_Label_pushButton = new QPushButton(tab_3);
        Picture_Label_pushButton->setObjectName(QString::fromUtf8("Picture_Label_pushButton"));
        Picture_Label_pushButton->setMinimumSize(QSize(100, 30));
        Picture_Label_pushButton->setMaximumSize(QSize(150, 35));

        verticalLayout_13->addWidget(Picture_Label_pushButton);


        horizontalLayout_2->addLayout(verticalLayout_13);


        verticalLayout_14->addLayout(horizontalLayout_2);


        verticalLayout_15->addLayout(verticalLayout_14);

        verticalSpacer_4 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_15->addItem(verticalSpacer_4);


        horizontalLayout_9->addLayout(verticalLayout_15);

        tabWidget->addTab(tab_3, QString());

        horizontalLayout_10->addWidget(tabWidget);


        retranslateUi(SearchWin);

        tabWidget->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(SearchWin);
    } // setupUi

    void retranslateUi(QDialog *SearchWin)
    {
        SearchWin->setWindowTitle(QCoreApplication::translate("SearchWin", "Dialog", nullptr));
        label_4->setText(QCoreApplication::translate("SearchWin", "\353\254\274\352\261\264 \352\262\200\354\203\211", nullptr));
        label->setText(QCoreApplication::translate("SearchWin", "Label:", nullptr));
        label_2->setText(QCoreApplication::translate("SearchWin", "\354\235\264\353\246\204:", nullptr));
        label_14->setText(QCoreApplication::translate("SearchWin", "Type:", nullptr));
        Object_Label_pushButton->setText(QCoreApplication::translate("SearchWin", "\352\262\200\354\203\211", nullptr));
        Object_Name_pushButton->setText(QCoreApplication::translate("SearchWin", "\352\262\200\354\203\211", nullptr));
        Object_Type_pushButton->setText(QCoreApplication::translate("SearchWin", "\352\262\200\354\203\211", nullptr));
        label_3->setText(QCoreApplication::translate("SearchWin", "\353\202\240\354\247\234\353\241\234 \352\262\200\354\203\211", nullptr));
        label_12->setText(QCoreApplication::translate("SearchWin", "From:", nullptr));
        label_13->setText(QCoreApplication::translate("SearchWin", "To:", nullptr));
        Object_Date_pushButton->setText(QCoreApplication::translate("SearchWin", "\352\262\200\354\203\211", nullptr));
        label_11->setText(QCoreApplication::translate("SearchWin", "\354\234\240\355\206\265\352\270\260\355\225\234:", nullptr));
        Object_DueDate_pushButton->setText(QCoreApplication::translate("SearchWin", "\352\262\200\354\203\211", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab), QCoreApplication::translate("SearchWin", "\353\254\274\352\261\264", nullptr));
        label_7->setText(QCoreApplication::translate("SearchWin", "\354\236\245\354\206\214 \352\262\200\354\203\211", nullptr));
        label_5->setText(QCoreApplication::translate("SearchWin", "Storage Label:", nullptr));
        label_6->setText(QCoreApplication::translate("SearchWin", "Floor:", nullptr));
        Storage_pushButton->setText(QCoreApplication::translate("SearchWin", "Storage \352\262\200\354\203\211", nullptr));
        Floor_pushButton->setText(QCoreApplication::translate("SearchWin", "Floor \352\262\200\354\203\211", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab_2), QCoreApplication::translate("SearchWin", "\354\236\245\354\206\214", nullptr));
        label_10->setText(QCoreApplication::translate("SearchWin", "\354\202\254\354\247\204 \352\262\200\354\203\211", nullptr));
        label_8->setText(QCoreApplication::translate("SearchWin", "\354\202\254\354\247\204 \352\262\275\353\241\234:", nullptr));
        label_9->setText(QCoreApplication::translate("SearchWin", "\353\254\274\352\261\264 Label:", nullptr));
        Picture_Path_pushButton->setText(QCoreApplication::translate("SearchWin", "\352\262\200\354\203\211", nullptr));
        Picture_Label_pushButton->setText(QCoreApplication::translate("SearchWin", "\352\262\200\354\203\211", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab_3), QCoreApplication::translate("SearchWin", "\354\202\254\354\247\204", nullptr));
    } // retranslateUi

};

namespace Ui {
    class SearchWin: public Ui_SearchWin {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SEARCHWIN_H
